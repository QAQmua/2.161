// 📄 完整替换文件：Foundation (底层基础)/AppAndWidgetRegistry.swift
import SwiftUI

// ==========================================
// 1. 桌面软件 (App) 协议与注册插座
// ==========================================
public struct AppDefinition: Identifiable {
    public let id: String
    public let defaultName: String
    public let defaultIcon: String
    public let defaultColorName: String
    public let viewBuilder: (Binding<Bool>) -> AnyView
}

@MainActor
public final class AppRegistry: ObservableObject {
    public static let shared = AppRegistry()
    @Published public var registeredApps: [String: AppDefinition] = [:]
    
    public func register<V: View>(id: String, name: String, icon: String, colorName: String, view: @escaping (Binding<Bool>) -> V) {
        registeredApps[id] = AppDefinition(
            id: id,
            defaultName: name,
            defaultIcon: icon,
            defaultColorName: colorName,
            viewBuilder: { AnyView(view($0)) }
        )
    }
    
    public var allApps: [AppDefinition] {
        Array(registeredApps.values).sorted(by: { $0.id < $1.id })
    }
}

// ==========================================
// 2. 桌面小组件 (Widget) 协议与纯净插座
// ==========================================
public protocol DesktopWidgetManager: AnyObject {
    var sizeRows: Int { get }
    var sizeCols: Int { get }
    var isAddedToDesktop: Bool { get set }
    var widgetPage: Int { get set }
    var widgetRow: Int { get set }
    var widgetCol: Int { get set }
}

extension InsPostWidgetManager: DesktopWidgetManager {
    public var sizeRows: Int { 4 }
    public var sizeCols: Int { 4 }
    public var widgetCol: Int { get { 0 } set {} }
}
extension KoreanMessageWidgetManager: DesktopWidgetManager {
    public var sizeRows: Int { 2 }
    public var sizeCols: Int { 4 }
    public var widgetCol: Int { get { 0 } set {} }
}
extension PhotoWidgetManager: DesktopWidgetManager {
    public var sizeRows: Int { 2 }
    public var sizeCols: Int { 4 }
    public var widgetCol: Int { get { 0 } set {} }
}
extension ChatBubbleWidgetManager: DesktopWidgetManager {
    public var sizeRows: Int { 2 }
    public var sizeCols: Int { 2 }
}

public struct WidgetDefinition: Identifiable {
    public let id: String
    public let titleKey: String
    public let subtitleKey: String
    public let sizeBadgeKey: String
    public let sizeRows: Int
    public let sizeCols: Int
    
    // 🌟 纯净 0 参数闭包，零编译器推断报错
    public let desktopView: () -> AnyView
    public let previewView: () -> AnyView
    public let editSheetView: (Binding<Bool>) -> AnyView
    
    public let manager: any DesktopWidgetManager
    
    public func shouldRender(on page: Int) -> Bool {
        return manager.isAddedToDesktop && manager.widgetPage == page
    }
}

@MainActor
public final class WidgetRegistry: ObservableObject {
    public static let shared = WidgetRegistry()
    @Published public var registeredWidgets: [WidgetDefinition] = []
    
    public func registerWidget<D: View, P: View, E: View>(
        id: String,
        title: String,
        subtitle: String,
        badge: String,
        manager: any DesktopWidgetManager,
        desktopView: @escaping () -> D,
        previewView: @escaping () -> P,
        editSheetView: @escaping (Binding<Bool>) -> E
    ) {
        guard !registeredWidgets.contains(where: { $0.id == id }) else { return }
        
        let def = WidgetDefinition(
            id: id,
            titleKey: title,
            subtitleKey: subtitle,
            sizeBadgeKey: badge,
            sizeRows: manager.sizeRows,
            sizeCols: manager.sizeCols,
            desktopView: { AnyView(desktopView()) },
            previewView: { AnyView(previewView()) },
            editSheetView: { AnyView(editSheetView($0)) },
            manager: manager
        )
        registeredWidgets.append(def)
    }
    
    public var activeManagers: [DesktopWidgetManager] {
        registeredWidgets.map { $0.manager }
    }
    
    public func widget(for id: String) -> WidgetDefinition? {
        registeredWidgets.first(where: { $0.id == id })
    }
}
