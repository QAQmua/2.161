// 📄 完整替换文件：Widgets/WidgetFanFolderSheet.swift
import SwiftUI
import PhotosUI
import UniformTypeIdentifiers

// MARK: - 相片文件夹专属编辑面板
struct EditFanFolderWidgetSheet: View {
    @Binding var isPresented: Bool
    @ObservedObject var mgr = FanFolderWidgetManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    
    @AppStorage("W_FF_PinPreview") private var isPreviewPinned: Bool = true
    @State private var selectedCategoryTab: Int = 0
    
    @State private var p1: PhotosPickerItem? = nil
    @State private var p2: PhotosPickerItem? = nil
    @State private var p3: PhotosPickerItem? = nil
    @State private var p4: PhotosPickerItem? = nil
    @State private var p5: PhotosPickerItem? = nil
    @State private var showFontPicker: Bool = false
    
    private var triggerKey: String { "\(selectedCategoryTab)" }
    
    private let colorPresets = [
        "#B4D4EE", "#F0CDDF", "#E2D0F0", "#D2EBD4", "#F5E6CC", "#E5E5EA"
    ]
    
    var body: some View {
        let s = uiScale
        NavigationStack {
            VStack(spacing: 0) {
                if isPreviewPinned {
                    pinnedHeaderView(s: s)
                        .overlay(alignment: .bottom) {
                            ZStack {
                                Rectangle().fill(.ultraThinMaterial)
                                LinearGradient(
                                    colors: [Color(UIColor.systemGroupedBackground), Color(UIColor.systemGroupedBackground).opacity(0)],
                                    startPoint: .top,
                                    endPoint: .bottom
                                )
                            }
                            .frame(height: 18)
                            .offset(y: 18)
                            .mask(
                                LinearGradient(
                                    stops: [.init(color: .black, location: 0.0), .init(color: .black.opacity(0.6), location: 0.4), .init(color: .clear, location: 1.0)],
                                    startPoint: .top,
                                    endPoint: .bottom
                                )
                            )
                            .allowsHitTesting(false)
                        }
                        .zIndex(10)
                }
                
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 16) {
                        if !isPreviewPinned {
                            pinnedHeaderView(s: s)
                                .padding(.top, 10)
                        }
                        
                        if selectedCategoryTab == 0 {
                            styleCategorySection()
                                .padding(.top, isPreviewPinned ? 14 : 0)
                        } else {
                            contentCategorySection()
                                .padding(.top, isPreviewPinned ? 14 : 0)
                        }
                    }
                    .padding(.bottom, 36)
                }
            }
            .background(Color(UIColor.systemGroupedBackground))
            .navigationTitle("相片文件夹 (2×2)".tr)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                            isPreviewPinned.toggle()
                        }
                    }) {
                        HStack(spacing: 4) {
                            Image(systemName: isPreviewPinned ? "pin.fill" : "pin.slash")
                                .font(.system(size: 13, weight: .semibold))
                            Text(isPreviewPinned ? "取消置顶".tr : "置顶预览".tr)
                                .font(.system(size: 13))
                        }
                        .foregroundColor(isPreviewPinned ? appearance.accentTextColor : .secondary)
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成".tr) {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        isPresented = false
                    }
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                    .foregroundColor(appearance.accentTextColor)
                }
            }
            .fileImporter(
                isPresented: $showFontPicker,
                allowedContentTypes: [.font, UTType(filenameExtension: "ttf") ?? .font, UTType(filenameExtension: "otf") ?? .font],
                allowsMultipleSelection: false
            ) { result in
                switch result {
                case .success(let urls):
                    if let selectedURL = urls.first {
                        _ = mgr.loadAndRegisterCustomFont(from: selectedURL)
                    }
                case .failure(let err):
                    print("Font import error: \(err)")
                }
            }
            .task(id: p1) { if let d = try? await p1?.loadTransferable(type: Data.self) { withAnimation { mgr.photo1Data = d }; p1 = nil } }
            .task(id: p2) { if let d = try? await p2?.loadTransferable(type: Data.self) { withAnimation { mgr.photo2Data = d }; p2 = nil } }
            .task(id: p3) { if let d = try? await p3?.loadTransferable(type: Data.self) { withAnimation { mgr.photo3Data = d }; p3 = nil } }
            .task(id: p4) { if let d = try? await p4?.loadTransferable(type: Data.self) { withAnimation { mgr.photo4Data = d }; p4 = nil } }
            .task(id: p5) { if let d = try? await p5?.loadTransferable(type: Data.self) { withAnimation { mgr.photo5Data = d }; p5 = nil } }
        }
        .presentationDetents([.medium, .large])
    }
    
    // MARK: - 预览与分段器
    private func pinnedHeaderView(s: CGFloat) -> some View {
        VStack(spacing: 12) {
            FanFolderWidget2x2View(manager: mgr, showDashedBorder: true)
                .frame(width: 155 * s, height: 155 * s)
                .shadow(color: .black.opacity(0.06), radius: 8, y: 3)
                .contentShape(Rectangle())
            
            Picker("", selection: $selectedCategoryTab.animation(.spring(response: 0.35, dampingFraction: 0.82))) {
                Text("样式".tr).tag(0)
                Text("内容".tr).tag(1)
            }
            .pickerStyle(.segmented)
            .padding(.horizontal, 24)
        }
        .padding(.top, 10)
        .padding(.bottom, 12)
        .frame(maxWidth: .infinity)
        .background(Color(UIColor.systemGroupedBackground))
    }
    
    // MARK: - 样式分类
    private func styleCategorySection() -> some View {
        VStack(spacing: 16) {
            // 文件夹颜色
            VStack(alignment: .leading, spacing: 14) {
                DominoScrollRevealWrapper(step: 0, triggerKey: triggerKey) {
                    Text("文件夹底色风格".tr)
                        .font(.system(size: 13, weight: appearance.systemFontWeight))
                        .foregroundColor(.secondary)
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                    WidgetColorPaletteRow(
                        title: "文件夹颜色".tr,
                        selectedHex: mgr.folderColorHex,
                        presets: colorPresets,
                        currentColor: Color(hex: mgr.folderColorHex),
                        onSelectHex: { mgr.folderColorHex = $0 },
                        onPickColor: { mgr.folderColorHex = $0.toHex() }
                    )
                }
            }
            .padding(16)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(18)
            .padding(.horizontal, 16)
            
            // 手写中文字体
            VStack(alignment: .leading, spacing: 14) {
                DominoScrollRevealWrapper(step: 0, triggerKey: triggerKey) {
                    Text("背面信笺字体".tr)
                        .font(.system(size: 13, weight: appearance.systemFontWeight))
                        .foregroundColor(.secondary)
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                    HStack(spacing: 12) {
                        Button {
                            showFontPicker = true
                        } label: {
                            HStack(spacing: 6) {
                                Image(systemName: "folder.badge.plus")
                                Text(mgr.customFontDisplayName.isEmpty ? "从文件导入中文字体 (.ttf / .otf)".tr : "更换字体: \(mgr.customFontDisplayName)")
                            }
                            .font(.system(size: 13, weight: .semibold))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                            .background(Color.blue)
                            .cornerRadius(10)
                        }
                        .buttonStyle(.plain)
                        
                        if !mgr.customFontDisplayName.isEmpty {
                            Button {
                                mgr.clearCustomFont()
                            } label: {
                                Image(systemName: "arrow.counterclockwise")
                                    .font(.system(size: 14, weight: .semibold))
                                    .foregroundColor(.secondary)
                                    .padding(10)
                                    .background(Color(UIColor.tertiarySystemFill))
                                    .clipShape(Circle())
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                
                DominoScrollRevealWrapper(step: 2, triggerKey: triggerKey) {
                    Text("💡 提示：从网上下载任何 .ttf 或 .otf 手写字体存入设备「文件」，点上方选中即可生效。".tr)
                        .font(.system(size: 11))
                        .foregroundColor(.secondary.opacity(0.8))
                        .lineSpacing(2)
                }
            }
            .padding(16)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(18)
            .padding(.horizontal, 16)
        }
    }
    
    // MARK: - 内容分类
    private func contentCategorySection() -> some View {
        VStack(spacing: 16) {
            VStack(alignment: .leading, spacing: 16) {
                DominoScrollRevealWrapper(step: 0, triggerKey: triggerKey) {
                    Text("相片与背面信件 (共 5 张)".tr)
                        .font(.system(size: 13, weight: appearance.systemFontWeight))
                        .foregroundColor(.secondary)
                }
                
                Divider()
                
                photoAndLetterCard(step: 1, title: "第 1 张 (最左)".tr, data: mgr.photo1Data, text: $mgr.photo1Text, sign: $mgr.photo1Sign, date: $mgr.photo1Date, picker: $p1, onClear: { mgr.photo1Data = nil })
                Divider()
                photoAndLetterCard(step: 2, title: "第 2 张 (次左)".tr, data: mgr.photo2Data, text: $mgr.photo2Text, sign: $mgr.photo2Sign, date: $mgr.photo2Date, picker: $p2, onClear: { mgr.photo2Data = nil })
                Divider()
                photoAndLetterCard(step: 3, title: "第 3 张 (正中)".tr, data: mgr.photo3Data, text: $mgr.photo3Text, sign: $mgr.photo3Sign, date: $mgr.photo3Date, picker: $p3, onClear: { mgr.photo3Data = nil })
                Divider()
                photoAndLetterCard(step: 4, title: "第 4 张 (次右)".tr, data: mgr.photo4Data, text: $mgr.photo4Text, sign: $mgr.photo4Sign, date: $mgr.photo4Date, picker: $p4, onClear: { mgr.photo4Data = nil })
                Divider()
                photoAndLetterCard(step: 5, title: "第 5 张 (最右)".tr, data: mgr.photo5Data, text: $mgr.photo5Text, sign: $mgr.photo5Sign, date: $mgr.photo5Date, picker: $p5, onClear: { mgr.photo5Data = nil })
            }
            .padding(16)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(18)
            .padding(.horizontal, 16)
        }
    }
    
    private func photoAndLetterCard(
        step: Int,
        title: String,
        data: Data?,
        text: Binding<String>,
        sign: Binding<String>,
        date: Binding<String>,
        picker: Binding<PhotosPickerItem?>,
        onClear: @escaping () -> Void
    ) -> some View {
        DominoScrollRevealWrapper(step: step, triggerKey: triggerKey) {
            VStack(alignment: .leading, spacing: 10) {
                HStack(spacing: 12) {
                    ZStack {
                        if let d = data, let uiImg = UIImage(data: d) {
                            Image(uiImage: uiImg).resizable().scaledToFill()
                        } else {
                            Color(UIColor.tertiarySystemFill)
                            Image(systemName: "photo").font(.system(size: 14)).foregroundColor(.secondary)
                        }
                    }
                    .frame(width: 44, height: 44)
                    .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
                    
                    Text(title).font(.system(size: 14, weight: appearance.systemFontWeight))
                    
                    Spacer()
                    
                    if data != nil {
                        Button(action: onClear) {
                            Image(systemName: "trash").font(.system(size: 13)).foregroundColor(.red)
                        }
                        .buttonStyle(.plain)
                    }
                    
                    PhotosPicker(selection: picker, matching: .images, photoLibrary: .shared()) {
                        Text(data == nil ? "选图".tr : "更换".tr)
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(.white)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 5)
                            .background(Color.blue)
                            .clipShape(Capsule())
                    }
                }
                
                TextField("输入背面写信正文...".tr, text: text, axis: .vertical)
                    .lineLimit(2...4)
                    .font(.system(size: 13))
                    .padding(10)
                    .background(Color(UIColor.tertiarySystemGroupedBackground))
                    .cornerRadius(10)
                
                HStack(spacing: 10) {
                    HStack(spacing: 4) {
                        Text("署名:".tr).font(.system(size: 12)).foregroundColor(.secondary)
                        TextField("如: — 见信好".tr, text: sign).font(.system(size: 12))
                    }
                    .padding(.horizontal, 8)
                    .padding(.vertical, 6)
                    .background(Color(UIColor.tertiarySystemGroupedBackground))
                    .cornerRadius(8)
                    
                    HStack(spacing: 4) {
                        Text("日期:".tr).font(.system(size: 12)).foregroundColor(.secondary)
                        TextField("如: 2024.10.14".tr, text: date).font(.system(size: 12))
                    }
                    .padding(.horizontal, 8)
                    .padding(.vertical, 6)
                    .background(Color(UIColor.tertiarySystemGroupedBackground))
                    .cornerRadius(8)
                }
            }
        }
    }
}
