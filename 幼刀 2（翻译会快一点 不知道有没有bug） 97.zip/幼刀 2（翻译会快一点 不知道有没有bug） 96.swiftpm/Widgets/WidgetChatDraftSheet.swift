// 📄 完整替换文件：Widgets/WidgetChatDraftSheet.swift
import SwiftUI
import PhotosUI

// MARK: - 专属编辑配置面板
struct EditChatDraftWidgetSheet: View {
    @Binding var isPresented: Bool
    @ObservedObject var mgr = ChatDraftWidgetManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    
    @AppStorage("W_CD_PinPreview") private var isPreviewPinned: Bool = true
    @State private var selectedCategoryTab: Int = 0
    @State private var pickerItem: PhotosPickerItem? = nil
    
    private var triggerKey: String { "\(selectedCategoryTab)" }
    
    private let colors = ["#F4F5F7", "#FFFFFF", "#000000", "#F2EBE5", "#EAF0F8", "#FCE7EC", "#E8F5E9", "#3A3A3C"]
    private let textColors = ["#3A3A3C", "#000000", "#8E8E93", "#FFFFFF", "#007AFF", "#FF2D55", "#FF9500"]
    private let cardColors = ["#FFFFFF", "#F9F9F9", "#1C1C1E", "#F4F5F7", "#FCE7EC"]
    
    var body: some View {
        let s = uiScale
        NavigationStack {
            VStack(spacing: 0) {
                if isPreviewPinned {
                    pinnedHeaderView(s: s)
                        .overlay(alignment: .bottom) {
                            ZStack {
                                Rectangle().fill(.ultraThinMaterial)
                                LinearGradient(
                                    colors: [Color(UIColor.systemGroupedBackground), Color(UIColor.systemGroupedBackground).opacity(0)],
                                    startPoint: .top,
                                    endPoint: .bottom
                                )
                            }
                            .frame(height: 18)
                            .offset(y: 18)
                            .mask(
                                LinearGradient(
                                    stops: [.init(color: .black, location: 0.0), .init(color: .black.opacity(0.6), location: 0.4), .init(color: .clear, location: 1.0)],
                                    startPoint: .top,
                                    endPoint: .bottom
                                )
                            )
                            .allowsHitTesting(false)
                        }
                        .zIndex(10)
                }
                
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 16) {
                        if !isPreviewPinned {
                            pinnedHeaderView(s: s)
                                .padding(.top, 10)
                        }
                        
                        if selectedCategoryTab == 0 {
                            styleCategorySection()
                                .padding(.top, isPreviewPinned ? 14 : 0)
                        } else {
                            contentCategorySection()
                                .padding(.top, isPreviewPinned ? 14 : 0)
                        }
                    }
                    .padding(.bottom, 36)
                }
            }
            .background(Color(UIColor.systemGroupedBackground))
            .navigationTitle("草稿卡片 (2×2)".tr)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                            isPreviewPinned.toggle()
                        }
                    }) {
                        HStack(spacing: 4) {
                            Image(systemName: isPreviewPinned ? "pin.fill" : "pin.slash")
                                .font(.system(size: 13, weight: .semibold))
                            Text(isPreviewPinned ? "取消置顶".tr : "置顶预览".tr)
                                .font(.system(size: 13))
                        }
                        .foregroundColor(isPreviewPinned ? appearance.accentTextColor : .secondary)
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成".tr) {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        isPresented = false
                    }
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                    .foregroundColor(appearance.accentTextColor)
                }
            }
            .task(id: pickerItem) {
                if let d = try? await pickerItem?.loadTransferable(type: Data.self) {
                    withAnimation { mgr.avatarData = d }
                    UINotificationFeedbackGenerator().notificationOccurred(.success)
                    pickerItem = nil
                }
            }
        }
        .presentationDetents([.medium, .large])
    }
    
    // MARK: - 预览与分段器
    private func pinnedHeaderView(s: CGFloat) -> some View {
        VStack(spacing: 12) {
            ChatDraftWidget2x2View(manager: mgr, showDashedBorder: true)
                .frame(width: 155 * s, height: 155 * s)
                .shadow(color: .black.opacity(0.08), radius: 8, y: 3)
                .contentShape(Rectangle())
            
            Picker("", selection: $selectedCategoryTab.animation(.spring(response: 0.35, dampingFraction: 0.82))) {
                Text("样式".tr).tag(0)
                Text("内容".tr).tag(1)
            }
            .pickerStyle(.segmented)
            .padding(.horizontal, 24)
        }
        .padding(.top, 10)
        .padding(.bottom, 12)
        .frame(maxWidth: .infinity)
        .background(Color(UIColor.systemGroupedBackground))
    }
    
    // MARK: - 样式分类
    private func styleCategorySection() -> some View {
        VStack(spacing: 16) {
            // 背景底色与透明度
            VStack(alignment: .leading, spacing: 14) {
                DominoScrollRevealWrapper(step: 0, triggerKey: triggerKey) {
                    Text("底板与卡片外观".tr)
                        .font(.system(size: 13, weight: appearance.systemFontWeight))
                        .foregroundColor(.secondary)
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                    Picker("", selection: $mgr.bgColorMode) {
                        Text("自选颜色 (默认)".tr).tag("color")
                        Text("完全透明".tr).tag("transparent")
                    }
                    .pickerStyle(.segmented)
                }
                
                if mgr.bgColorMode == "color" {
                    Divider()
                    
                    DominoScrollRevealWrapper(step: 2, triggerKey: triggerKey) {
                        WidgetColorPaletteRow(
                            title: "底板背景颜色".tr,
                            selectedHex: mgr.bgColorHex,
                            presets: colors,
                            currentColor: Color(hex: mgr.bgColorHex),
                            onSelectHex: { mgr.bgColorHex = $0 },
                            onPickColor: { mgr.bgColorHex = $0.toHex() }
                        )
                    }
                    
                    Divider()
                    
                    DominoScrollRevealWrapper(step: 3, triggerKey: triggerKey) {
                        VStack(alignment: .leading, spacing: 6) {
                            HStack {
                                Text("背景不透明度".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                                Spacer()
                                Text("\(Int(mgr.bgOpacity * 100))%").font(.caption).foregroundColor(.secondary)
                            }
                            Slider(value: $mgr.bgOpacity, in: 0.0...1.0, step: 0.05)
                                .tint(appearance.sliderTrackColor)
                        }
                    }
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 4, triggerKey: triggerKey) {
                    WidgetColorPaletteRow(
                        title: "输入框卡片底色".tr,
                        selectedHex: mgr.cardBgHex,
                        presets: cardColors,
                        currentColor: Color(hex: mgr.cardBgHex),
                        onSelectHex: { mgr.cardBgHex = $0 },
                        onPickColor: { mgr.cardBgHex = $0.toHex() }
                    )
                }
            }
            .padding(16)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(18)
            .padding(.horizontal, 16)
            
            // 光标与文本色彩
            VStack(alignment: .leading, spacing: 14) {
                DominoScrollRevealWrapper(step: 0, triggerKey: triggerKey) {
                    Text("光标与正文样式".tr)
                        .font(.system(size: 13, weight: appearance.systemFontWeight))
                        .foregroundColor(.secondary)
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                    Toggle("显示首行闪烁竖线光标 (|)".tr, isOn: $mgr.showCursor)
                        .font(.system(size: 15, weight: appearance.systemFontWeight))
                        .tint(appearance.toggleTintColor)
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 2, triggerKey: triggerKey) {
                    WidgetColorPaletteRow(
                        title: "正文字体颜色".tr,
                        selectedHex: mgr.textColorHex,
                        presets: textColors,
                        currentColor: Color(hex: mgr.textColorHex),
                        onSelectHex: { mgr.textColorHex = $0 },
                        onPickColor: { mgr.textColorHex = $0.toHex() }
                    )
                }
            }
            .padding(16)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(18)
            .padding(.horizontal, 16)
        }
    }
    
    // MARK: - 内容分类
    private func contentCategorySection() -> some View {
        VStack(spacing: 16) {
            // 头像
            VStack(alignment: .leading, spacing: 14) {
                DominoScrollRevealWrapper(step: 0, triggerKey: triggerKey) {
                    Text("左上角头像".tr)
                        .font(.system(size: 13, weight: appearance.systemFontWeight))
                        .foregroundColor(.secondary)
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                    HStack(spacing: 12) {
                        ZStack {
                            if let d = mgr.avatarData, let uiImg = UIImage(data: d) {
                                Image(uiImage: uiImg).resizable().scaledToFill()
                            } else {
                                Color(UIColor.tertiarySystemFill)
                                Image(systemName: "person.fill").font(.system(size: 18)).foregroundColor(.secondary)
                            }
                        }
                        .frame(width: 52, height: 52)
                        .clipShape(Circle())
                        
                        PhotosPicker(selection: $pickerItem, matching: .images, photoLibrary: .shared()) {
                            VStack(alignment: .leading, spacing: 3) {
                                Text(mgr.avatarData == nil ? "选取头像照片".tr : "更换头像照片".tr)
                                    .font(.system(size: 15, weight: .medium)).foregroundColor(.primary)
                                Text("点击从相册替换头像".tr).font(.system(size: 12)).foregroundColor(.secondary)
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        
                        if mgr.avatarData != nil {
                            Button(action: {
                                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                withAnimation { mgr.avatarData = nil }
                            }) {
                                Image(systemName: "xmark.circle.fill").font(.system(size: 20)).foregroundColor(Color(UIColor.tertiaryLabel))
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal, 12).padding(.vertical, 8)
                    .background(Color(UIColor.tertiarySystemFill).opacity(0.55)).cornerRadius(14)
                }
            }
            .padding(16)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(18)
            .padding(.horizontal, 16)
            
            // 草稿文字
            VStack(alignment: .leading, spacing: 14) {
                DominoScrollRevealWrapper(step: 0, triggerKey: triggerKey) {
                    HStack {
                        Text("草稿文本 (桌面亦可直接点击编辑)".tr)
                            .font(.system(size: 13, weight: appearance.systemFontWeight))
                            .foregroundColor(.secondary)
                        Spacer()
                        Button("恢复原图内容".tr) {
                            withAnimation {
                                mgr.draftContent = ChatDraftWidgetManager.defaultDraftText
                            }
                        }
                        .font(.caption)
                        .foregroundColor(.blue)
                    }
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                    ZStack(alignment: .topLeading) {
                        TextEditor(text: $mgr.draftContent)
                            .font(.subheadline)
                            .frame(minHeight: 110)
                            .scrollContentBackground(.hidden)
                            .background(Color.clear)
                    }
                    .padding(10)
                    .background(Color(UIColor.tertiarySystemFill))
                    .cornerRadius(10)
                }
            }
            .padding(16)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(18)
            .padding(.horizontal, 16)
        }
    }
}
