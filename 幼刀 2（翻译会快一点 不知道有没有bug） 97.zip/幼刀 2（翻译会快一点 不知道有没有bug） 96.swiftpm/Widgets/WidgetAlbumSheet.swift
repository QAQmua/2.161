import SwiftUI
import PhotosUI

// MARK: - 🌟 柔和无裁切视口感知多米诺骨牌模块包裹器 (向下滑动慢慢展现 · 零卡顿 · 切界面防消失版)
struct DominoScrollRevealWrapper<Content: View>: View {
    let step: Int
    let triggerKey: String
    @ViewBuilder let content: () -> Content
    
    @State private var hasRevealed: Bool = false
    @State private var lastRecordedMinY: CGFloat = 9999
    
    var body: some View {
        content()
            .opacity(hasRevealed ? 1.0 : 0.0)
            .blur(radius: hasRevealed ? 0.0 : 6.0)
            .scaleEffect(hasRevealed ? 1.0 : 0.98)
            .offset(y: hasRevealed ? 0 : 18)
            .background(
                GeometryReader { geo in
                    Color.clear
                        .onAppear {
                            lastRecordedMinY = geo.frame(in: .global).minY
                            checkVisibility(minY: lastRecordedMinY)
                        }
                        .onChange(of: geo.frame(in: .global).minY) { _, minY in
                            lastRecordedMinY = minY
                            // 🌟 防卡顿核心：未展开时才计算，一旦展开立刻休眠，滑动彻底不掉帧！
                            if !hasRevealed {
                                checkVisibility(minY: minY)
                            }
                        }
                }
            )
            .onChange(of: triggerKey) { _, _ in
                // 🌟 切分类、切卡片时精准重置，保证切回来时向下滑动依然有展现动画！
                hasRevealed = false
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.03) {
                    checkVisibility(minY: lastRecordedMinY)
                }
            }
    }
    
    private func checkVisibility(minY: CGFloat) {
        guard !hasRevealed else { return }
        let screenHeight = UIScreen.main.bounds.height
        
        // 当用户向下滑动，元素滚入视口时触发弹性水润对焦
        if minY < (screenHeight - 35) && minY > -120 {
            let delay = Double(step) * 0.065
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.01) {
                withAnimation(.spring(response: 0.65, dampingFraction: 0.86).delay(delay)) {
                    hasRevealed = true
                }
            }
        }
    }
}

// MARK: - 相册插画专属编辑面板（两大分类：样式 · 内容 · 滚动视口展现版）
@MainActor
struct EditAlbumWidgetSheet: View {
    @Binding var isPresented: Bool
    @ObservedObject var mgr = AlbumWidgetManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    
    // 是否吸顶常驻预览
    @AppStorage("W_AL_PinPreview") private var isPreviewPinned: Bool = true
    
    // 两大顶级分类：0: 样式 (包含全局外观、形态与调色), 1: 内容
    @State private var selectedCategoryTab: Int = 0
    
    // 联合触发信号：切分类或切卡片序号都会通知重新捕获滚动视口
    private var triggerKey: String {
        "\(selectedCategoryTab)_\(mgr.currentCardIndex)"
    }
    
    // 三层卡片独立选图 Picker
    @State private var photoItem1: PhotosPickerItem? = nil
    @State private var photoItem2: PhotosPickerItem? = nil
    @State private var photoItem3: PhotosPickerItem? = nil
    
    // HSB 调色面板状态
    @State private var colorPickerTitle: String = ""
    @State private var colorStorageKey: String = ""
    @State private var activeHexBinding: Binding<String>? = nil
    @State private var activePresetColors: [String] = []
    @State private var showHSBSheet: Bool = false
    
    private var morandiPresets: [String] { SystemAppearance.morandiPresets }
    
    var body: some View {
        let s = uiScale
        NavigationStack {
            VStack(spacing: 0) {
                // 1. 【置顶预览与分类分段器：样式 · 内容】
                if isPreviewPinned {
                    pinnedHeaderView(s: s)
                        .overlay(alignment: .bottom) {
                            ZStack {
                                Rectangle()
                                    .fill(.ultraThinMaterial)
                                LinearGradient(
                                    colors: [
                                        Color(UIColor.systemGroupedBackground),
                                        Color(UIColor.systemGroupedBackground).opacity(0)
                                    ],
                                    startPoint: .top,
                                    endPoint: .bottom
                                )
                            }
                            .frame(height: 18)
                            .offset(y: 18)
                            .mask(
                                LinearGradient(
                                    stops: [
                                        .init(color: .black, location: 0.0),
                                        .init(color: .black.opacity(0.6), location: 0.4),
                                        .init(color: .clear, location: 1.0)
                                    ],
                                    startPoint: .top,
                                    endPoint: .bottom
                                )
                            )
                            .allowsHitTesting(false)
                        }
                        .zIndex(10)
                }
                
                // 2. 【滚动展示区：向下滑动慢慢展现内容】
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 16) {
                        if !isPreviewPinned {
                            pinnedHeaderView(s: s)
                                .padding(.top, 10)
                        }
                        
                        if selectedCategoryTab == 0 {
                            // 🌟 【样式】分类
                            styleCategorySection()
                                .padding(.top, isPreviewPinned ? 14 : 0)
                        } else {
                            // 🌟 【内容】分类
                            contentCategorySection()
                                .padding(.top, isPreviewPinned ? 14 : 0)
                        }
                    }
                    .padding(.bottom, 36)
                }
            }
            .background(Color(UIColor.systemGroupedBackground))
            .navigationTitle("相册插画".tr)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                            isPreviewPinned.toggle()
                        }
                    }) {
                        HStack(spacing: 4) {
                            Image(systemName: isPreviewPinned ? "pin.fill" : "pin.slash")
                                .font(.system(size: 13, weight: .semibold))
                            Text(isPreviewPinned ? "取消置顶".tr : "置顶预览".tr)
                                .font(.system(size: 13))
                        }
                        .foregroundColor(isPreviewPinned ? appearance.accentTextColor : .secondary)
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成".tr) {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        isPresented = false
                    }
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                    .foregroundColor(appearance.accentTextColor)
                }
            }
            .sheet(isPresented: $showHSBSheet) {
                if let hexBinding = activeHexBinding {
                    ProfessionalHSBSheet(
                        title: colorPickerTitle,
                        storageKey: colorStorageKey,
                        hexBinding: hexBinding,
                        presets: activePresetColors
                    )
                    .presentationDetents([.height(400)])
                }
            }
            .task(id: photoItem1) {
                if let data = try? await photoItem1?.loadTransferable(type: Data.self) {
                    await MainActor.run {
                        withAnimation(.easeInOut(duration: 0.28)) { self.mgr.image1Data = data }
                        UINotificationFeedbackGenerator().notificationOccurred(.success)
                        photoItem1 = nil
                    }
                }
            }
            .task(id: photoItem2) {
                if let data = try? await photoItem2?.loadTransferable(type: Data.self) {
                    await MainActor.run {
                        withAnimation(.easeInOut(duration: 0.28)) { self.mgr.image2Data = data }
                        UINotificationFeedbackGenerator().notificationOccurred(.success)
                        photoItem2 = nil
                    }
                }
            }
            .task(id: photoItem3) {
                if let data = try? await photoItem3?.loadTransferable(type: Data.self) {
                    await MainActor.run {
                        withAnimation(.easeInOut(duration: 0.28)) { self.mgr.image3Data = data }
                        UINotificationFeedbackGenerator().notificationOccurred(.success)
                        photoItem3 = nil
                    }
                }
            }
        }
        .presentationDetents([.medium, .large])
    }
    
    // MARK: - 🏆 顶部吸顶区域
    private func pinnedHeaderView(s: CGFloat) -> some View {
        VStack(spacing: 12) {
            AlbumWidget2x2View(manager: mgr, showDashedBorder: true)
                .frame(width: 155 * s, height: 155 * s)
                .shadow(color: .black.opacity(0.08), radius: 8, y: 3)
                .contentShape(Rectangle())
                .onTapGesture {
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    withAnimation(.spring(response: 0.40, dampingFraction: 0.78)) {
                        mgr.switchToNextCard()
                    }
                }
            
            Picker("", selection: $selectedCategoryTab.animation(.spring(response: 0.35, dampingFraction: 0.82))) {
                Text("样式".tr).tag(0)
                Text("内容".tr).tag(1)
            }
            .pickerStyle(.segmented)
            .padding(.horizontal, 24)
        }
        .padding(.top, 10)
        .padding(.bottom, 12)
        .frame(maxWidth: .infinity)
        .background(Color(UIColor.systemGroupedBackground))
    }
    
    // MARK: - 📁 分类 1：【样式】
    private func styleCategorySection() -> some View {
        VStack(spacing: 16) {
            // 卡片 1：全局外观
            globalSettingsCard()
            
            // 卡片 2：形态与边距
            VStack(alignment: .leading, spacing: 14) {
                VStack(alignment: .leading, spacing: 12) {
                    DominoScrollRevealWrapper(step: 0, triggerKey: triggerKey) {
                        Text("卡片形态与边距".tr)
                            .font(.system(size: 13, weight: appearance.systemFontWeight))
                            .foregroundColor(.secondary)
                    }
                    
                    if mgr.cardLayersCount > 1 {
                        cardIndexSegmentedPicker()
                    }
                }
                
                Divider()
                
                ZStack(alignment: .top) {
                    if mgr.currentCardIndex == 0 {
                        cardLayoutEditor(cardIndex: 1, insetBinding: $mgr.card1Inset, hasBorder: $mgr.hasCard1Border, borderWidth: $mgr.card1BorderWidth, borderHex: $mgr.card1BorderColorHex)
                    } else if mgr.currentCardIndex == 1 {
                        cardLayoutEditor(cardIndex: 2, insetBinding: $mgr.card2Inset, hasBorder: $mgr.hasCard2Border, borderWidth: $mgr.card2BorderWidth, borderHex: $mgr.card2BorderColorHex)
                    } else {
                        cardLayoutEditor(cardIndex: 3, insetBinding: $mgr.card3Inset, hasBorder: $mgr.hasCard3Border, borderWidth: $mgr.card3BorderWidth, borderHex: $mgr.card3BorderColorHex)
                    }
                }
            }
            .padding(16)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(18)
            .padding(.horizontal, 16)
            
            // 卡片 3：配色
            VStack(alignment: .leading, spacing: 14) {
                VStack(alignment: .leading, spacing: 12) {
                    DominoScrollRevealWrapper(step: 0, triggerKey: triggerKey) {
                        Text("卡片与顶栏配色".tr)
                            .font(.system(size: 13, weight: appearance.systemFontWeight))
                            .foregroundColor(.secondary)
                    }
                    
                    if mgr.cardLayersCount > 1 {
                        cardIndexSegmentedPicker()
                    }
                }
                
                Divider()
                
                ZStack(alignment: .top) {
                    if mgr.currentCardIndex == 0 {
                        cardColorOnlyEditor(cardIndex: 1, cardBgHex: $mgr.card1ColorHex, capsuleHex: $mgr.capsule1BgColorHex, circleHex: $mgr.circle1BgColorHex, textHex: $mgr.text1ColorHex, iconHex: $mgr.icon1ColorHex)
                    } else if mgr.currentCardIndex == 1 {
                        cardColorOnlyEditor(cardIndex: 2, cardBgHex: $mgr.card2ColorHex, capsuleHex: $mgr.capsule2BgColorHex, circleHex: $mgr.circle2BgColorHex, textHex: $mgr.text2ColorHex, iconHex: $mgr.icon2ColorHex)
                    } else {
                        cardColorOnlyEditor(cardIndex: 3, cardBgHex: $mgr.card3ColorHex, capsuleHex: $mgr.capsule3BgColorHex, circleHex: $mgr.circle3BgColorHex, textHex: $mgr.text3ColorHex, iconHex: $mgr.icon3ColorHex)
                    }
                }
            }
            .padding(16)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(18)
            .padding(.horizontal, 16)
        }
    }
    
    // 卡片 1 内部：全局外观
    private func globalSettingsCard() -> some View {
        VStack(alignment: .leading, spacing: 14) {
            DominoScrollRevealWrapper(step: 0, triggerKey: triggerKey) {
                VStack(alignment: .leading, spacing: 10) {
                    Text("小组件全局外观".tr)
                        .font(.system(size: 13, weight: appearance.systemFontWeight))
                        .foregroundColor(.secondary)
                    
                    Picker("层数".tr, selection: $mgr.cardLayersCount) {
                        Text("1 层".tr).tag(1)
                        Text("2 层".tr).tag(2)
                        Text("3 层".tr).tag(3)
                    }
                    .pickerStyle(.segmented)
                    .onChange(of: mgr.cardLayersCount) { _, newCount in
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        if mgr.currentCardIndex >= newCount {
                            withAnimation(.spring(response: 0.38, dampingFraction: 0.76)) {
                                mgr.currentCardIndex = 0
                            }
                        }
                    }
                }
            }
            
            Divider()
            
            DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                VStack(alignment: .leading, spacing: 10) {
                    Toggle(isOn: $mgr.hasOuterBorder.animation(.spring(response: 0.36, dampingFraction: 0.82))) {
                        Label("外边缘描边".tr, systemImage: "square.dashed")
                            .font(.system(size: 14, weight: appearance.systemFontWeight))
                    }
                    .tint(appearance.toggleTintColor)
                    
                    if mgr.hasOuterBorder {
                        VStack(alignment: .leading, spacing: 10) {
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text("粗细".tr).font(.system(size: 13, weight: appearance.systemFontWeight)).foregroundColor(.secondary)
                                    Spacer()
                                    Text(String(format: "%.1f pt", mgr.outerBorderWidth)).font(.caption).foregroundColor(.secondary)
                                }
                                Slider(value: $mgr.outerBorderWidth, in: 0.4...3.0, step: 0.1)
                                    .tint(appearance.sliderTrackColor)
                            }
                            sleekColorRow(title: "颜色".tr, storageKey: "outer_border", hexBinding: $mgr.outerBorderColorHex, presets: morandiPresets)
                        }
                    }
                }
            }
            
            Divider()
            
            DominoScrollRevealWrapper(step: 2, triggerKey: triggerKey) {
                VStack(alignment: .leading, spacing: 6) {
                    Text("外观底色风格".tr)
                        .font(.system(size: 13, weight: appearance.systemFontWeight))
                        .foregroundColor(.secondary)
                    
                    Picker("外观样式".tr, selection: $mgr.bgColorMode.animation(.easeInOut(duration: 0.2))) {
                        Text("默认".tr).tag("default")
                        Text("纯白".tr).tag("white")
                        Text("纯黑".tr).tag("black")
                        Text("透明".tr).tag("transparent")
                    }
                    .pickerStyle(.segmented)
                }
            }
            
            Divider()
            
            DominoScrollRevealWrapper(step: 3, triggerKey: triggerKey) {
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("图片圆角".tr)
                            .font(.system(size: 14, weight: appearance.systemFontWeight))
                            .foregroundColor(.primary)
                        Spacer()
                        Text(String(format: "%.0f pt", mgr.imageCornerRadius))
                            .font(.system(size: 13, weight: .medium, design: .monospaced))
                            .foregroundColor(.secondary)
                    }
                    Slider(value: $mgr.imageCornerRadius, in: 0.0...24.0, step: 1.0)
                        .tint(appearance.sliderTrackColor)
                }
            }
        }
        .padding(16)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(18)
        .padding(.horizontal, 16)
    }
    
    // 卡片 2 内部：单卡形态与边距
    private func cardLayoutEditor(
        cardIndex: Int,
        insetBinding: Binding<Double>,
        hasBorder: Binding<Bool>,
        borderWidth: Binding<Double>,
        borderHex: Binding<String>
    ) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("两侧收窄边距".tr)
                            .font(.system(size: 14, weight: appearance.systemFontWeight))
                            .foregroundColor(.primary)
                        Spacer()
                        Text(String(format: "%.1f pt", insetBinding.wrappedValue))
                            .font(.system(size: 13, weight: .medium, design: .monospaced))
                            .foregroundColor(.secondary)
                    }
                    Slider(value: insetBinding, in: 2.0...28.0, step: 0.5)
                        .tint(appearance.sliderTrackColor)
                }
            }
            
            Divider()
            
            DominoScrollRevealWrapper(step: 2, triggerKey: triggerKey) {
                VStack(alignment: .leading, spacing: 10) {
                    Toggle(isOn: hasBorder.animation(.spring(response: 0.36, dampingFraction: 0.82))) {
                        Text("卡片外描边".tr)
                            .font(.system(size: 14, weight: appearance.systemFontWeight))
                            .foregroundColor(.primary)
                    }
                    .tint(appearance.toggleTintColor)
                    
                    if hasBorder.wrappedValue {
                        VStack(alignment: .leading, spacing: 10) {
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text("描边粗细".tr)
                                        .font(.system(size: 13, weight: appearance.systemFontWeight))
                                        .foregroundColor(.secondary)
                                    Spacer()
                                    Text(String(format: "%.1f pt", borderWidth.wrappedValue))
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                                Slider(value: borderWidth, in: 0.4...3.0, step: 0.1)
                                    .tint(appearance.sliderTrackColor)
                            }
                            sleekColorRow(title: "描边颜色".tr, storageKey: "c\(cardIndex)_border", hexBinding: borderHex, presets: morandiPresets)
                        }
                        .padding(.top, 2)
                    }
                }
            }
        }
    }
    
    // 卡片 3 内部：单卡配色清单
    private func cardColorOnlyEditor(
        cardIndex: Int,
        cardBgHex: Binding<String>,
        capsuleHex: Binding<String>,
        circleHex: Binding<String>,
        textHex: Binding<String>,
        iconHex: Binding<String>
    ) -> some View {
        VStack(spacing: 12) {
            DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                sleekColorRow(title: "卡片底色".tr, storageKey: "c\(cardIndex)_bg", hexBinding: cardBgHex, presets: morandiPresets)
            }
            Divider().padding(.leading, 8)
            DominoScrollRevealWrapper(step: 2, triggerKey: triggerKey) {
                sleekColorRow(title: "胶囊底色".tr, storageKey: "c\(cardIndex)_cap", hexBinding: capsuleHex, presets: morandiPresets)
            }
            Divider().padding(.leading, 8)
            DominoScrollRevealWrapper(step: 3, triggerKey: triggerKey) {
                sleekColorRow(title: "圆钮底色".tr, storageKey: "c\(cardIndex)_cir", hexBinding: circleHex, presets: morandiPresets)
            }
            Divider().padding(.leading, 8)
            DominoScrollRevealWrapper(step: 4, triggerKey: triggerKey) {
                sleekColorRow(title: "标题文字颜色".tr, storageKey: "c\(cardIndex)_txt", hexBinding: textHex, presets: morandiPresets)
            }
            Divider().padding(.leading, 8)
            DominoScrollRevealWrapper(step: 5, triggerKey: triggerKey) {
                sleekColorRow(title: "按钮图标颜色".tr, storageKey: "c\(cardIndex)_ico", hexBinding: iconHex, presets: morandiPresets)
            }
        }
    }
    
    // MARK: - 📝 分类 2：【内容】
    private func contentCategorySection() -> some View {
        VStack(alignment: .leading, spacing: 14) {
            VStack(alignment: .leading, spacing: 12) {
                DominoScrollRevealWrapper(step: 0, triggerKey: triggerKey) {
                    Text("内容与配图".tr)
                        .font(.system(size: 13, weight: appearance.systemFontWeight))
                        .foregroundColor(.secondary)
                }
                
                // 🌟 直接原样展示原生 Segmented Picker，绝不重构，不受 .blur 破坏，字迹纯净锐利
                if mgr.cardLayersCount > 1 {
                    cardIndexSegmentedPicker()
                }
            }
            
            Divider()
            
            ZStack(alignment: .top) {
                if mgr.currentCardIndex == 0 {
                    cardContentEditor(nameBinding: $mgr.title1, imageData: mgr.image1Data, pickerBinding: $photoItem1, onClear: { mgr.image1Data = nil })
                } else if mgr.currentCardIndex == 1 {
                    cardContentEditor(nameBinding: $mgr.title2, imageData: mgr.image2Data, pickerBinding: $photoItem2, onClear: { mgr.image2Data = nil })
                } else {
                    cardContentEditor(nameBinding: $mgr.title3, imageData: mgr.image3Data, pickerBinding: $photoItem3, onClear: { mgr.image3Data = nil })
                }
            }
        }
        .padding(16)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(18)
        .padding(.horizontal, 16)
    }
    
    // 单卡内容编辑器
    private func cardContentEditor(
        nameBinding: Binding<String>,
        imageData: Data?,
        pickerBinding: Binding<PhotosPickerItem?>,
        onClear: @escaping () -> Void
    ) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                HStack {
                    Text("标题:".tr)
                        .font(.system(size: 14, weight: appearance.systemFontWeight))
                        .foregroundColor(.secondary)
                    TextField("输入卡片标题", text: nameBinding)
                        .font(.subheadline)
                        .padding(8)
                        .background(Color(UIColor.tertiarySystemFill))
                        .cornerRadius(8)
                }
            }
            
            DominoScrollRevealWrapper(step: 2, triggerKey: triggerKey) {
                HStack(spacing: 12) {
                    ZStack {
                        if let data = imageData, let uiImg = UIImage(data: data) {
                            Image(uiImage: uiImg)
                                .resizable()
                                .scaledToFill()
                                .transition(.blurFade)
                        } else {
                            Color(UIColor.tertiarySystemFill)
                            Image(systemName: "photo.badge.plus")
                                .font(.system(size: 18))
                                .foregroundColor(.secondary)
                                .transition(.opacity)
                        }
                    }
                    .frame(width: 52, height: 52)
                    .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
                    
                    PhotosPicker(selection: pickerBinding, matching: .images, photoLibrary: .shared()) {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(imageData == nil ? "选取插画图片".tr : "更换插画图片".tr)
                                .font(.system(size: 15, weight: .medium))
                                .foregroundColor(.primary)
                            Text(imageData == nil ? "点击从相册选择专属插画".tr : "点击重新选择替换图片".tr)
                                .font(.system(size: 12))
                                .foregroundColor(.secondary)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    
                    ZStack {
                        if imageData != nil {
                            Button(action: {
                                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                withAnimation(.easeInOut(duration: 0.32)) { onClear() }
                            }) {
                                Image(systemName: "xmark.circle.fill")
                                    .font(.system(size: 20))
                                    .foregroundColor(Color(UIColor.tertiaryLabel))
                                    .frame(width: 32, height: 32)
                                    .contentShape(Circle())
                            }
                            .buttonStyle(.plain)
                        } else {
                            Image(systemName: "chevron.right")
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundColor(Color(UIColor.tertiaryLabel))
                        }
                    }
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 10)
                .background(Color(UIColor.tertiarySystemFill).opacity(0.55))
                .cornerRadius(14)
            }
        }
    }
    
    // 🌟 原汁原味系统原生 Segmented Picker：移除外层动画冲突，字迹 100% 恢复锐利清晰
    private func cardIndexSegmentedPicker() -> some View {
        Picker("", selection: $mgr.currentCardIndex) {
            ForEach(0..<mgr.cardLayersCount, id: \.self) { idx in
                Text("第 \(idx + 1) 张".tr).tag(idx)
            }
        }
        .pickerStyle(.segmented)
    }
    
    // 原生标准调色行
    private func sleekColorRow(title: String, storageKey: String, hexBinding: Binding<String>, presets: [String]) -> some View {
        Button(action: {
            colorPickerTitle = title
            colorStorageKey = storageKey
            activeHexBinding = hexBinding
            activePresetColors = presets
            showHSBSheet = true
        }) {
            HStack {
                Text(title)
                    .font(.system(size: 14, weight: appearance.systemFontWeight))
                    .foregroundColor(.primary)
                Spacer()
                
                HStack(spacing: 8) {
                    Circle()
                        .fill(hexBinding.wrappedValue.isEmpty ? Color.clear : Color(hex: hexBinding.wrappedValue))
                        .frame(width: 24, height: 24)
                        .overlay(Circle().stroke(Color.black.opacity(0.18), lineWidth: 1.2))
                        .shadow(color: Color.black.opacity(0.06), radius: 2, y: 1)
                    
                    Image(systemName: "chevron.right")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(Color(UIColor.tertiaryLabel))
                }
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

// MARK: - 专业纯净级 HSB 调色控制台
@MainActor
struct ProfessionalHSBSheet: View {
    let title: String
    let storageKey: String
    @Binding var hexBinding: String
    let presets: [String]
    @Environment(\.dismiss) private var dismiss
    
    @State private var hue: Double = 0.0
    @State private var saturation: Double = 0.25
    @State private var brightness: Double = 0.75
    
    @State private var savedColors: [String] = []
    
    @State private var colorToDelete: String? = nil
    @State private var showDeleteConfirmation: Bool = false
    
    var currentColor: Color {
        Color(hue: hue, saturation: saturation, brightness: brightness)
    }
    
    private var storageKeyName: String {
        "W_AL_PropColors_" + storageKey
    }
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                VStack(spacing: 12) {
                    HStack(spacing: 14) {
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .fill(currentColor)
                            .frame(width: 46, height: 46)
                            .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.secondary.opacity(0.2), lineWidth: 1))
                        
                        VStack(alignment: .leading, spacing: 3) {
                            Text(title)
                                .font(.system(size: 16, weight: .semibold))
                            
                            HStack(spacing: 6) {
                                Text(hexBinding.uppercased())
                                    .font(.system(size: 13, weight: .bold, design: .monospaced))
                                
                                Text("• H:\(Int(hue * 360))° S:\(Int(saturation * 100))% B:\(Int(brightness * 100))%")
                                    .font(.system(size: 11, weight: .medium, design: .monospaced))
                                    .foregroundColor(.secondary)
                            }
                        }
                        
                        Spacer()
                        
                        Button(action: {
                            UIImpactFeedbackGenerator(style: .light).impactOccurred()
                            SystemEyedropper.shared.open(initialHex: hexBinding) { newHex in
                                hexBinding = newHex
                                parseInitialHex()
                            }
                        }) {
                            HStack(spacing: 5) {
                                Image(systemName: "eyedropper.halffull")
                                    .font(.system(size: 12, weight: .semibold))
                                Text("吸色".tr)
                                    .font(.system(size: 12, weight: .medium))
                            }
                            .foregroundColor(.primary)
                            .padding(.horizontal, 11)
                            .padding(.vertical, 6)
                            .background(Color(UIColor.tertiarySystemFill))
                            .clipShape(Capsule())
                        }
                        .buttonStyle(.plain)
                    }
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 12) {
                            Button(action: {
                                saveCurrentColor()
                            }) {
                                ZStack {
                                    Circle()
                                        .strokeBorder(Color.secondary.opacity(0.35), style: StrokeStyle(lineWidth: 1.5, dash: [3, 3]))
                                        .frame(width: 30, height: 30)
                                    Image(systemName: "plus")
                                        .font(.system(size: 12, weight: .bold))
                                        .foregroundColor(.primary)
                                }
                                .frame(width: 36, height: 36)
                                .contentShape(Circle())
                                .clipShape(Circle())
                            }
                            .buttonStyle(.plain)
                            
                            ForEach(savedColors, id: \.self) { hex in
                                let isSel = hex.uppercased() == hexBinding.uppercased()
                                ZStack {
                                    Circle()
                                        .fill(Color(hex: hex))
                                        .frame(width: 26, height: 26)
                                    
                                    if isSel {
                                        Circle()
                                            .stroke(Color(hex: "#8FA4B5"), lineWidth: 2.5)
                                            .frame(width: 34, height: 34)
                                    } else {
                                        Circle()
                                            .stroke(Color.secondary.opacity(0.2), lineWidth: 1)
                                            .frame(width: 26, height: 26)
                                    }
                                }
                                .frame(width: 36, height: 36)
                                .contentShape(Circle())
                                .onTapGesture {
                                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                    hexBinding = hex
                                    parseInitialHex()
                                }
                                .onLongPressGesture(minimumDuration: 0.4) {
                                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                                    colorToDelete = hex
                                    showDeleteConfirmation = true
                                }
                            }
                        }
                        .padding(.horizontal, 4)
                        .padding(.vertical, 4)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 10)
                
                Divider()
                
                VStack(spacing: 14) {
                    nativeHSBSliderRow(
                        title: "色相",
                        displayValue: "\(Int(hue * 360))°",
                        value: $hue,
                        onMinus: {
                            hue = max(0.0, (hue * 360 - 1).rounded() / 360.0)
                            syncHex()
                        },
                        onPlus: {
                            hue = min(1.0, (hue * 360 + 1).rounded() / 360.0)
                            syncHex()
                        },
                        gradientColors: (0...360).map { Color(hue: Double($0) / 360.0, saturation: 0.35, brightness: 0.85) }
                    )
                    
                    nativeHSBSliderRow(
                        title: "饱和度",
                        displayValue: "\(Int(saturation * 100))%",
                        value: $saturation,
                        onMinus: {
                            saturation = max(0.0, (saturation * 100 - 1).rounded() / 100.0)
                            syncHex()
                        },
                        onPlus: {
                            saturation = min(1.0, (saturation * 100 + 1).rounded() / 100.0)
                            syncHex()
                        },
                        gradientColors: [
                            Color(hue: hue, saturation: 0.05, brightness: brightness),
                            Color(hue: hue, saturation: 0.85, brightness: brightness)
                        ]
                    )
                    
                    nativeHSBSliderRow(
                        title: "明度",
                        displayValue: "\(Int(brightness * 100))%",
                        value: $brightness,
                        onMinus: {
                            brightness = max(0.0, (brightness * 100 - 1).rounded() / 100.0)
                            syncHex()
                        },
                        onPlus: {
                            brightness = min(1.0, (brightness * 100 + 1).rounded() / 100.0)
                            syncHex()
                        },
                        gradientColors: [
                            Color(hex: "#333333"),
                            Color(hue: hue, saturation: saturation, brightness: 0.95)
                        ]
                    )
                }
                .padding(.horizontal, 20)
                
                Spacer()
            }
            .navigationTitle("HSB 调色器".tr)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成".tr) { dismiss() }
                        .font(.system(size: 16, weight: .semibold))
                }
            }
            .confirmationDialog("删除该颜色".tr, isPresented: $showDeleteConfirmation, titleVisibility: .visible) {
                Button("删除此颜色".tr, role: .destructive) {
                    if let target = colorToDelete {
                        removeColor(target)
                    }
                }
                Button("取消".tr, role: .cancel) {}
            }
            .onAppear {
                parseInitialHex()
                loadSavedColors()
            }
        }
    }
    
    private func saveCurrentColor() {
        let current = hexBinding.uppercased()
        guard !current.isEmpty else { return }
        if !savedColors.contains(current) {
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
            withAnimation(.spring(response: 0.36, dampingFraction: 0.70)) {
                savedColors.insert(current, at: 0)
            }
            UserDefaults.standard.set(savedColors, forKey: storageKeyName)
        }
    }
    
    private func removeColor(_ hex: String) {
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        withAnimation(.spring(response: 0.32, dampingFraction: 0.72)) {
            savedColors.removeAll { $0.uppercased() == hex.uppercased() }
        }
        UserDefaults.standard.set(savedColors, forKey: storageKeyName)
    }
    
    private func loadSavedColors() {
        if let saved = UserDefaults.standard.stringArray(forKey: storageKeyName), !saved.isEmpty {
            savedColors = saved
        } else {
            savedColors = presets.isEmpty ? SystemAppearance.morandiPresets : presets
            UserDefaults.standard.set(savedColors, forKey: storageKeyName)
        }
    }
    
    private func nativeHSBSliderRow(
        title: String,
        displayValue: String,
        value: Binding<Double>,
        onMinus: @escaping () -> Void,
        onPlus: @escaping () -> Void,
        gradientColors: [Color]
    ) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(title.tr)
                    .font(.system(size: 13, weight: .semibold))
                Spacer()
                Text(displayValue)
                    .font(.system(size: 13, weight: .bold, design: .monospaced))
                    .foregroundColor(.secondary)
            }
            
            HStack(spacing: 12) {
                Button(action: {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    onMinus()
                }) {
                    Image(systemName: "minus")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(.primary)
                        .frame(width: 28, height: 28)
                        .background(Color(UIColor.tertiarySystemFill))
                        .clipShape(Circle())
                }
                .buttonStyle(.plain)
                
                ZStack {
                    LinearGradient(gradient: Gradient(colors: gradientColors), startPoint: .leading, endPoint: .trailing)
                        .frame(height: 8)
                        .cornerRadius(4)
                        .padding(.horizontal, 4)
                    
                    NativeSliderRepresentable(value: value) {
                        syncHex()
                    }
                    .frame(height: 32)
                }
                .frame(maxWidth: .infinity)
                
                Button(action: {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    onPlus()
                }) {
                    Image(systemName: "plus")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(.primary)
                        .frame(width: 28, height: 28)
                        .background(Color(UIColor.tertiarySystemFill))
                        .clipShape(Circle())
                }
                .buttonStyle(.plain)
            }
        }
    }
    
    private func syncHex() {
        let uiColor = UIColor(hue: CGFloat(hue), saturation: CGFloat(saturation), brightness: CGFloat(brightness), alpha: 1.0)
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        uiColor.getRed(&r, green: &g, blue: &b, alpha: &a)
        hexBinding = String(format: "#%02lX%02lX%02lX", lroundf(Float(r * 255)), lroundf(Float(g * 255)), lroundf(Float(g * 255)))
    }
    
    private func parseInitialHex() {
        guard !hexBinding.isEmpty else { return }
        let uiColor = UIColor(Color(hex: hexBinding))
        var h: CGFloat = 0, s: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        if uiColor.getHue(&h, saturation: &s, brightness: &b, alpha: &a) {
            hue = Double(h)
            saturation = Double(s)
            brightness = Double(b)
        }
    }
}

// MARK: - 系统原生吸色控制器
@MainActor
final class SystemEyedropper: NSObject, UIColorPickerViewControllerDelegate {
    static let shared = SystemEyedropper()
    private var onPicked: ((String) -> Void)?
    
    func open(initialHex: String, onPicked: @escaping (String) -> Void) {
        self.onPicked = onPicked
        guard let windowScene = UIApplication.shared.connectedScenes.first(where: { $0.activationState == .foregroundActive }) as? UIWindowScene ?? UIApplication.shared.connectedScenes.first as? UIWindowScene,
              let rootVC = windowScene.windows.first(where: { $0.isKeyWindow })?.rootViewController else { return }
        
        var topVC = rootVC
        while let presented = topVC.presentedViewController, !presented.isBeingDismissed {
            topVC = presented
        }
        
        let picker = UIColorPickerViewController()
        picker.selectedColor = UIColor(Color(hex: initialHex))
        picker.supportsAlpha = false
        picker.delegate = self
        
        if let popover = picker.popoverPresentationController {
            popover.sourceView = topVC.view
            popover.sourceRect = CGRect(x: topVC.view.bounds.midX, y: topVC.view.bounds.midY, width: 0, height: 0)
            popover.permittedArrowDirections = []
        }
        
        topVC.present(picker, animated: true)
    }
    
    func colorPickerViewController(_ viewController: UIColorPickerViewController, didSelect color: UIColor, continuously: Bool) {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        color.getRed(&r, green: &g, blue: &b, alpha: &a)
        let hex = String(format: "#%02lX%02lX%02lX", lroundf(Float(r * 255)), lroundf(Float(g * 255)), lroundf(Float(g * 255)))
        onPicked?(hex)
    }
}

// 纯原生 UIKit UISlider 桥接
struct NativeSliderRepresentable: UIViewRepresentable {
    @Binding var value: Double
    let onEditingChanged: () -> Void
    
    func makeUIView(context: Context) -> UISlider {
        let slider = UISlider(frame: .zero)
        slider.minimumValue = 0.0
        slider.maximumValue = 1.0
        slider.minimumTrackTintColor = .clear
        slider.maximumTrackTintColor = .clear
        slider.value = Float(value)
        
        slider.addTarget(
            context.coordinator,
            action: #selector(Coordinator.valueChanged(_:)),
            for: .valueChanged
        )
        return slider
    }
    
    func updateUIView(_ uiView: UISlider, context: Context) {
        if abs(Double(uiView.value) - value) > 0.001 {
            uiView.value = Float(value)
        }
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject {
        var parent: NativeSliderRepresentable
        
        init(_ parent: NativeSliderRepresentable) {
            self.parent = parent
        }
        
        @objc func valueChanged(_ sender: UISlider) {
            parent.value = Double(sender.value)
            parent.onEditingChanged()
        }
    }
}
