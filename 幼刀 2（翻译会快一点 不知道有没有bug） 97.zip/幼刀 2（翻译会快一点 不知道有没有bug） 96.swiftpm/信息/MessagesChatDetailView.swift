// 📄 文件路径：信息/MessagesChatDetailView.swift
import SwiftUI
import PhotosUI
import AudioToolbox

// MARK: - 1. 可选铃声音效列表
struct ChatSoundOption: Identifiable, Hashable {
    let id: Int
    let name: String
}

let chatSendSoundOptions: [ChatSoundOption] = [
    ChatSoundOption(id: 1004, name: "经典飞跃 (Swoosh - 默认)"),
    ChatSoundOption(id: 1057, name: "轻柔弹泡 (Pop)"),
    ChatSoundOption(id: 1000, name: "清脆铃音 (Ding)"),
    ChatSoundOption(id: 1001, name: "疾风邮件 (Whoosh)"),
    ChatSoundOption(id: 1016, name: "灵动鸟鸣 (Tweet)"),
    ChatSoundOption(id: 1025, name: "空灵钟琴 (Chime)"),
    ChatSoundOption(id: 0,    name: "静音 (无声音)")
]

let chatReceiveSoundOptions: [ChatSoundOption] = [
    ChatSoundOption(id: 1005, name: "经典三音 (Tri-tone - 默认)"),
    ChatSoundOption(id: 1003, name: "电子短音 (Note)"),
    ChatSoundOption(id: 1002, name: "玻璃轻敲 (Glass)"),
    ChatSoundOption(id: 1000, name: "清脆叮咚 (Ding)"),
    ChatSoundOption(id: 1057, name: "轻柔弹泡 (Pop)"),
    ChatSoundOption(id: 1016, name: "灵动鸟鸣 (Tweet)"),
    ChatSoundOption(id: 1025, name: "空灵钟琴 (Chime)"),
    ChatSoundOption(id: 0,    name: "静音 (无声音)")
]

extension Color {
    func toHexString() -> String {
        let uic = UIColor(self)
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        guard uic.getRed(&r, green: &g, blue: &b, alpha: &a) else { return "#007AFF" }
        return String(format: "#%02X%02X%02X", Int(r * 255), Int(g * 255), Int(b * 255))
    }
}

// MARK: - 2. 聊天详情界面
@MainActor
struct MessagesChatDetailView: View {
    let conversationID: String
    @ObservedObject var viewModel = MessagesViewModel.shared
    @ObservedObject var netEngine = MessagesNetworkEngine.shared
    @Environment(\.colorScheme) private var colorScheme
    
    @AppStorage private var selectedSendSoundID: Int
    @AppStorage private var selectedReceiveSoundID: Int
    @AppStorage private var customBubbleColorHex: String
    @AppStorage private var customTextColorHex: String
    @AppStorage private var customPeerBubbleColorHex: String
    @AppStorage private var customPeerTextColorHex: String
    @AppStorage private var customSendButtonColorHex: String
    @AppStorage private var bgImageID: String
    @AppStorage private var chatFontSize: Double
    
    @State private var inputText: String = ""
    @State private var selectedPhotoItem: PhotosPickerItem? = nil
    @State private var avatarPhotoItem: PhotosPickerItem? = nil
    @State private var replyingToMessage: IMMessageItem? = nil
    @State private var showSendEffectSheet: Bool = false
    @State private var showContactInfoSheet: Bool = false
    @State private var revealedInvisibleIDs: Set<String> = []
    @FocusState private var isInputFocused: Bool
    
    @State private var isSelectionMode: Bool = false
    @State private var selectedMessageIDs: Set<String> = []
    @State private var showClearAllConfirm: Bool = false
    
    init(conversationID: String) {
        self.conversationID = conversationID
        self._selectedSendSoundID = AppStorage(wrappedValue: 1004, "chat_send_sound_\(conversationID)")
        self._selectedReceiveSoundID = AppStorage(wrappedValue: 1005, "chat_receive_sound_\(conversationID)")
        self._customBubbleColorHex = AppStorage(wrappedValue: "", "chat_bubble_color_\(conversationID)")
        self._customTextColorHex = AppStorage(wrappedValue: "", "chat_text_color_\(conversationID)")
        self._customPeerBubbleColorHex = AppStorage(wrappedValue: "", "chat_peer_bubble_color_\(conversationID)")
        self._customPeerTextColorHex = AppStorage(wrappedValue: "", "chat_peer_text_color_\(conversationID)")
        self._customSendButtonColorHex = AppStorage(wrappedValue: "", "chat_send_btn_color_\(conversationID)")
        self._bgImageID = AppStorage(wrappedValue: "", "chat_bg_image_\(conversationID)")
        self._chatFontSize = AppStorage(wrappedValue: 16.5, "chat_font_size_\(conversationID)")
    }
    
    private var conversation: IMConversation? {
        viewModel.conversations.first(where: { $0.id == conversationID })
    }
    
    private var isPeerTyping: Bool {
        guard let conv = conversation else { return false }
        let norm = MessagesNetworkEngine.normalizeID(conv.peerID)
        return viewModel.peerTypingMap[norm] ?? false
    }
    
    var body: some View {
        let s = uiScale
        ZStack {
            (colorScheme == .dark ? Color(hex: "#010001") : Color(UIColor.systemBackground))
                .ignoresSafeArea()
            
            if !bgImageID.isEmpty,
               let data = LocalImageStore.shared.load(id: bgImageID),
               let uiImg = ImageBitmapCache.shared.image(from: data) {
                Image(uiImage: uiImg)
                    .resizable()
                    .scaledToFill()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .ignoresSafeArea()
                    .overlay(Color.black.opacity(colorScheme == .dark ? 0.35 : 0.08))
            }
            
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(spacing: 0) {
                        if let conv = conversation {
                            VStack(spacing: 3 * s) {
                                Text(conv.isSMSChannel ? "iMessage信息" : "iMessage信息")
                                    .font(.system(size: 11 * s, weight: .medium))
                                
                                HStack(spacing: 3 * s) {
                                    Image(systemName: "lock.fill")
                                        .font(.system(size: 11 * s))
                                    Text("已加密")
                                        .font(.system(size: 11 * s, weight: .medium))
                                }
                            }
                            .foregroundStyle(.secondary)
                            .padding(.top, 60 * s)
                            .padding(.bottom, 12 * s)
                            
                            let msgs = conv.messages
                            ForEach(Array(msgs.enumerated()), id: \.element.id) { index, msg in
                                let showTime = index == 0 || msg.timestamp.timeIntervalSince(msgs[index - 1].timestamp) > 3600
                                
                                let hasTimeGapWithNext = (index + 1 < msgs.count) && (msgs[index + 1].timestamp.timeIntervalSince(msg.timestamp) > 3600)
                                let hasTimeGapWithPrev = (index > 0) && (msg.timestamp.timeIntervalSince(msgs[index - 1].timestamp) > 3600)
                                
                                let isNextSame = (index + 1 < msgs.count) && (msgs[index + 1].isFromMe == msg.isFromMe) && !hasTimeGapWithNext
                                let isPrevSame = (index > 0) && (msg.timestamp.timeIntervalSince(msgs[index - 1].timestamp) > 3600)
                                let isLastFromMe = (index == msgs.lastIndex(where: { $0.isFromMe }))
                                
                                NativeMessageBubbleRow(
                                    message: msg,
                                    isPrevSameSender: isPrevSame,
                                    isNextSameSender: isNextSame,
                                    isLastSentMessage: isLastFromMe,
                                    showTimeHeader: showTime,
                                    isInvisibleRevealed: revealedInvisibleIDs.contains(msg.id),
                                    fontSize: CGFloat(chatFontSize),
                                    isSelectionMode: isSelectionMode,
                                    isSelected: selectedMessageIDs.contains(msg.id),
                                    customBubbleColor: customBubbleColorHex.isEmpty ? nil : Color(hex: customBubbleColorHex),
                                    customTextColor: customTextColorHex.isEmpty ? nil : Color(hex: customTextColorHex),
                                    customPeerBubbleColor: customPeerBubbleColorHex.isEmpty ? nil : Color(hex: customPeerBubbleColorHex),
                                    customPeerTextColor: customPeerTextColorHex.isEmpty ? nil : Color(hex: customPeerTextColorHex),
                                    onRevealInvisible: {
                                        withAnimation { _ = revealedInvisibleIDs.insert(msg.id) }
                                    },
                                    onToggleSelect: {
                                        toggleMessageSelection(msg.id)
                                    },
                                    onStartSelectMode: {
                                        withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                                            isSelectionMode = true
                                            selectedMessageIDs.insert(msg.id)
                                        }
                                    },
                                    onTapback: { symbol in
                                        viewModel.sendTapback(in: conv.id, messageID: msg.id, symbol: symbol)
                                    },
                                    onReply: {
                                        withAnimation {
                                            replyingToMessage = msg
                                            isInputFocused = true
                                        }
                                    },
                                    onDelete: {
                                        if let cIdx = viewModel.conversations.firstIndex(where: { $0.id == conv.id }) {
                                            withAnimation {
                                                viewModel.conversations[cIdx].messages.removeAll(where: { $0.id == msg.id })
                                                viewModel.saveConversations()
                                            }
                                        }
                                    }
                                )
                                .id(msg.id)
                            }
                        }
                        
                        if isPeerTyping {
                            HStack {
                                NativeTypingIndicatorBubble()
                                Spacer()
                            }
                            .padding(.horizontal, 16 * s)
                            .padding(.top, 4 * s)
                            .id("typing_indicator")
                            .transition(
                                .asymmetric(
                                    insertion: .scale(scale: 0.5, anchor: .bottomLeading).combined(with: .opacity),
                                    removal: .scale(scale: 0.75, anchor: .bottomLeading).combined(with: .opacity)
                                )
                            )
                        }
                        
                        Color.clear.frame(height: 10 * s).id("bottom_anchor")
                    }
                    .animation(.spring(response: 0.38, dampingFraction: 0.78), value: isPeerTyping)
                }
                .scrollDismissesKeyboard(.interactively)
                .modifier(IOS26NativeBottomSafeAreaBar {
                    if isSelectionMode {
                        nativeBottomSelectionBar
                    } else {
                        nativeBottomInputBar
                    }
                })
                .onReceive(NotificationCenter.default.publisher(for: UIResponder.keyboardWillShowNotification)) { _ in
                    withAnimation(.spring(response: 0.38, dampingFraction: 0.82)) {
                        proxy.scrollTo("bottom_anchor", anchor: .bottom)
                    }
                }
                .onChange(of: isPeerTyping) { _, isTyping in
                    if isTyping {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.02) {
                            withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                                proxy.scrollTo("typing_indicator", anchor: .bottom)
                            }
                        }
                    }
                }
                .onChange(of: conversation?.messages.count) { oldCount, newCount in
                    viewModel.markConversationAsRead(conversationID)
                    guard let old = oldCount, let new = newCount, new > old else { return }
                    
                    if let lastMsg = conversation?.messages.last, !lastMsg.isFromMe {
                        let receiveSound = selectedReceiveSoundID
                        if receiveSound != 0 {
                            DispatchQueue.global(qos: .userInteractive).async {
                                AudioServicesPlaySystemSound(SystemSoundID(receiveSound))
                            }
                        }
                        
                        ChatNotificationManager.shared.scheduleMessageNotification(
                            senderName: conversation?.name ?? "新信息",
                            messageText: lastMsg.text.isEmpty ? "[图片]" : lastMsg.text,
                            conversationID: conversationID,
                            delay: 1.0
                        )
                    }
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
                        withAnimation(.spring(response: 0.38, dampingFraction: 0.82)) {
                            proxy.scrollTo("bottom_anchor", anchor: .bottom)
                        }
                    }
                }
                .onAppear {
                    viewModel.markConversationAsRead(conversationID)
                    ChatNotificationManager.shared.requestAuthorization()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
                        proxy.scrollTo("bottom_anchor", anchor: .bottom)
                    }
                }
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            if isSelectionMode {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("完成") {
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.82)) {
                            isSelectionMode = false
                            selectedMessageIDs.removeAll()
                        }
                    }
                    .font(.system(size: 17 * s, weight: .bold))
                }
            } else {
                if #available(iOS 26.0, *) {
                    ToolbarItem(placement: .principal) {
                        principalHeaderItem
                    }
                    .sharedBackgroundVisibility(.hidden)
                } else {
                    ToolbarItem(placement: .principal) {
                        principalHeaderItem
                    }
                }
                
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showContactInfoSheet = true
                    } label: {
                        Image(systemName: "video")
                    }
                }
            }
        }
        .confirmationDialog("使用特效发送", isPresented: $showSendEffectSheet, titleVisibility: .visible) {
            Button("震撼 (Slam)") { commitSend(effect: "slam") }
            Button("响亮 (Loud)") { commitSend(effect: "loud") }
            Button("轻柔 (Gentle)") { commitSend(effect: "gentle") }
            Button("隐形墨水 (刮开可见)") { commitSend(effect: "invisible") }
            Button("取消", role: .cancel) {}
        }
        .confirmationDialog("确定要清空该会话所有聊天记录吗？", isPresented: $showClearAllConfirm, titleVisibility: .visible) {
            Button("全部删除", role: .destructive) {
                clearAllMessages()
            }
            Button("取消", role: .cancel) {}
        }
        .sheet(isPresented: $showContactInfoSheet) {
            if let conv = conversation {
                NativeContactDetailSheet(
                    conversation: conv,
                    avatarPhotoItem: $avatarPhotoItem,
                    selectedSendSoundID: $selectedSendSoundID,
                    selectedReceiveSoundID: $selectedReceiveSoundID,
                    customBubbleColorHex: $customBubbleColorHex,
                    customTextColorHex: $customTextColorHex,
                    customPeerBubbleColorHex: $customPeerBubbleColorHex,
                    customPeerTextColorHex: $customPeerTextColorHex,
                    customSendButtonColorHex: $customSendButtonColorHex,
                    bgImageID: $bgImageID,
                    chatFontSize: $chatFontSize,
                    onClearAll: {
                        clearAllMessages()
                    }
                )
                .presentationDetents([.medium, .large])
            }
        }
        .task(id: selectedPhotoItem) {
            if let item = selectedPhotoItem,
               let data = try? await item.loadTransferable(type: Data.self) {
                withAnimation(.spring(response: 0.4, dampingFraction: 0.75)) {
                    viewModel.sendMessage(in: conversationID, text: "", imageData: data, replyTo: replyingToMessage)
                }
                replyingToMessage = nil
                selectedPhotoItem = nil
            }
        }
        .task(id: avatarPhotoItem) {
            if let item = avatarPhotoItem,
               let data = try? await item.loadTransferable(type: Data.self),
               let idx = viewModel.conversations.firstIndex(where: { $0.id == conversationID }) {
                viewModel.conversations[idx].avatarImageID = LocalImageStore.shared.save(data: data)
                viewModel.saveConversations()
                avatarPhotoItem = nil
            }
        }
        .onChange(of: inputText) { _, newValue in
            guard let conv = conversation, !conv.isAIContact && !conv.isSMSChannel else { return }
            viewModel.sendTypingStatus(to: conv.peerID, isTyping: !newValue.isEmpty)
        }
    }
    
    // MARK: - 顶栏 (带 1.16 缩放)
    @ViewBuilder
    private var principalHeaderItem: some View {
        let s = uiScale
        if let conv = conversation {
            Button {
                showContactInfoSheet = true
            } label: {
                let arrowSize: CGFloat = 13.3 * s
                
                let namePill = HStack(spacing: 5.5 * s) {
                    Text(conv.name)
                        .font(.system(size: 17 * s, weight: .bold))
                        .fontWeight(.bold)
                        .foregroundStyle(.primary)
                        .lineLimit(1)
                        .truncationMode(.tail)
                    
                    Canvas { context, size in
                        let cs = size.height / 11.0
                        var path = Path()
                        path.move(to: CGPoint(x: 1.2 * cs, y: 1.5 * cs))
                        path.addLine(to: CGPoint(x: 3.0 * cs, y: 5.5 * cs))
                        path.addLine(to: CGPoint(x: 1.2 * cs, y: 9.5 * cs))
                        context.stroke(
                            path,
                            with: .color(.secondary.opacity(0.62)),
                            style: StrokeStyle(lineWidth: 2.1 * cs, lineCap: .round, lineJoin: .round)
                        )
                    }
                    .frame(width: arrowSize * (4.5 / 11.0), height: arrowSize)
                }
                    .frame(height: 18 * s)
                    .padding(.leading, 12.3 * s)
                    .padding(.trailing, 9.7 * s)
                    .padding(.vertical, 7.5 * s)
                    .frame(maxWidth: 180 * s)
                
                let avatar = NativeContactAvatarView(
                    name: conv.name,
                    colorHex: conv.avatarColorHex,
                    imageID: conv.avatarImageID,
                    size: 58 * s
                )
                    .shadow(color: .black.opacity(0.18), radius: 6 * s, x: 0, y: 3 * s)
                
                ZStack(alignment: Alignment(horizontal: .center, vertical: .top)) {
                    if #available(iOS 26.0, *) {
                        namePill
                            .glassEffect(.regular, in: .capsule)
                            .padding(.top, 53 * s)
                    } else {
                        namePill
                            .background(.regularMaterial, in: Capsule())
                            .padding(.top, 53 * s)
                    }
                    
                    avatar
                }
                .frame(maxWidth: 200 * s)
                .offset(y: 18 * s)
            }
            .buttonStyle(.plain)
        }
    }
    
    // MARK: - 原生多选底部工具栏
    @ViewBuilder
    private var nativeBottomSelectionBar: some View {
        let s = uiScale
        HStack {
            Button(role: .destructive) {
                showClearAllConfirm = true
            } label: {
                Text("全部删除")
                    .font(.system(size: 16 * s, weight: .regular))
                    .foregroundStyle(.red)
            }
            
            Spacer()
            
            Text(selectedMessageIDs.isEmpty ? "轻点勾选信息" : "已选择 \(selectedMessageIDs.count) 条")
                .font(.system(size: 14 * s))
                .foregroundStyle(.secondary)
            
            Spacer()
            
            Button {
                deleteSelectedMessages()
            } label: {
                Image(systemName: "trash")
                    .font(.system(size: 19 * s))
                    .foregroundStyle(selectedMessageIDs.isEmpty ? Color.secondary.opacity(0.4) : Color.red)
            }
            .disabled(selectedMessageIDs.isEmpty)
        }
        .padding(.horizontal, 24 * s)
        .padding(.vertical, 12 * s)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22 * s, style: .continuous))
        .padding(.horizontal, 16 * s)
        .padding(.vertical, 6 * s)
        .transition(.move(edge: .bottom).combined(with: .opacity))
    }
    
    // MARK: - 原生底部输入栏
    @ViewBuilder
    private var nativeBottomInputBar: some View {
        let s = uiScale
        let isTypingActive = isInputFocused || !inputText.isEmpty
        
        let plusMenu = Menu {
            PhotosPicker(selection: $selectedPhotoItem, matching: .images, photoLibrary: .shared()) {
                Label("照片", systemImage: "photo.on.rectangle")
            }
            Button {
                showSendEffectSheet = true
            } label: {
                Label("发送特效", systemImage: "sparkles")
            }
            Button {
                showContactInfoSheet = true
            } label: {
                Label("更换对方头像与备注", systemImage: "person.crop.circle")
            }
        } label: {
            Image(systemName: "plus")
                .font(.system(size: 19 * s, weight: .semibold))
                .foregroundStyle(Color(UIColor.label))
                .frame(width: 38 * s, height: 38 * s)
        }
        
        let sendBtnColor: Color = {
            if !customSendButtonColorHex.isEmpty {
                return Color(hex: customSendButtonColorHex)
            } else if !customBubbleColorHex.isEmpty {
                return Color(hex: customBubbleColorHex)
            } else {
                return conversation?.isSMSChannel == true ? Color(hex: "#34C759") : Color(hex: "#007AFF")
            }
        }()
        
        let textFieldCapsule = HStack(alignment: .bottom, spacing: 8 * s) {
            ZStack(alignment: .leading) {
                if inputText.isEmpty {
                    Text(conversation?.isSMSChannel == true ? "iMessage信息" : "iMessage信息")
                        .font(.system(size: 14.5 * s, weight: .regular))
                        .foregroundStyle(.secondary.opacity(0.72))
                        .padding(.vertical, 8 * s)
                        .padding(.leading, 14 * s)
                        .allowsHitTesting(false)
                }
                
                TextField("", text: $inputText, axis: .vertical)
                    .font(.system(size: 16.5 * s, weight: .regular))
                    .lineLimit(1...5)
                    .focused($isInputFocused)
                    .padding(.vertical, 8 * s)
                    .padding(.leading, 14 * s)
            }
            
            let canSend = !inputText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            if canSend {
                Button {
                    commitSend(effect: nil)
                } label: {
                    ZStack {
                        Capsule()
                            .fill(sendBtnColor)
                            .frame(width: 36 * s, height: 27 * s)
                        
                        Text("↑")
                            .font(.system(size: 19 * s, weight: .heavy))
                            .foregroundStyle(.white)
                            .offset(y: 0)
                    }
                }
                .simultaneousGesture(
                    LongPressGesture(minimumDuration: 0.45).onEnded { _ in
                        UIImpactFeedbackGenerator(style: .heavy).impactOccurred()
                        showSendEffectSheet = true
                    }
                )
                .padding(.trailing, 7 * s)
                .padding(.bottom, 4.7 * s)
            } else {
                Image(systemName: "mic")
                    .font(.system(size: 16 * s))
                    .foregroundStyle(.secondary)
                    .padding(.trailing, 14 * s)
                    .padding(.bottom, 9 * s)
            }
        }
            .frame(minHeight: 40 * s)
        
        Group {
            if #available(iOS 26.0, *) {
                GlassEffectContainer(spacing: 10 * s) {
                    HStack(alignment: .bottom, spacing: 10 * s) {
                        plusMenu
                            .glassEffect(.regular.interactive(), in: .circle)
                        textFieldCapsule
                            .glassEffect(.regular.interactive(), in: .rect(cornerRadius: 20 * s))
                    }
                }
            } else {
                HStack(alignment: .bottom, spacing: 10 * s) {
                    plusMenu
                        .background(.ultraThinMaterial, in: Circle())
                    textFieldCapsule
                        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20 * s, style: .continuous))
                }
            }
        }
        .padding(.horizontal, isTypingActive ? 20 * s : 25 * s)
        .padding(.vertical, 6 * s)
        .animation(.spring(response: 0.35, dampingFraction: 0.82), value: isTypingActive)
    }
    
    private func toggleMessageSelection(_ id: String) {
        withAnimation(.easeInOut(duration: 0.18)) {
            if selectedMessageIDs.contains(id) {
                selectedMessageIDs.remove(id)
            } else {
                selectedMessageIDs.insert(id)
            }
        }
    }
    
    private func deleteSelectedMessages() {
        guard let conv = conversation, !selectedMessageIDs.isEmpty else { return }
        if let cIdx = viewModel.conversations.firstIndex(where: { $0.id == conv.id }) {
            withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                viewModel.conversations[cIdx].messages.removeAll(where: { selectedMessageIDs.contains($0.id) })
                viewModel.saveConversations()
                selectedMessageIDs.removeAll()
                isSelectionMode = false
            }
        }
    }
    
    private func clearAllMessages() {
        guard let conv = conversation else { return }
        if let cIdx = viewModel.conversations.firstIndex(where: { $0.id == conv.id }) {
            withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                viewModel.conversations[cIdx].messages.removeAll()
                viewModel.saveConversations()
                selectedMessageIDs.removeAll()
                isSelectionMode = false
            }
        }
    }
    
    private func commitSend(effect: String?) {
        let trimmed = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        
        let soundToPlay = selectedSendSoundID
        if soundToPlay != 0 {
            DispatchQueue.global(qos: .userInteractive).async {
                AudioServicesPlaySystemSound(SystemSoundID(soundToPlay))
            }
        }
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        
        withAnimation(.spring(response: 0.4, dampingFraction: 0.75)) {
            viewModel.sendMessage(
                in: conversationID,
                text: trimmed,
                imageData: nil,
                replyTo: replyingToMessage,
                effect: effect
            )
        }
        
        inputText = ""
        replyingToMessage = nil
    }
}

// MARK: - 3. 底部 Safe Area 兼容修饰器
struct IOS26NativeBottomSafeAreaBar<BarContent: View>: ViewModifier {
    @ViewBuilder let barContent: () -> BarContent
    
    func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            content
                .safeAreaBar(edge: .bottom) {
                    barContent()
                }
                .scrollEdgeEffectStyle(.soft, for: .bottom)
        } else {
            content
                .safeAreaInset(edge: .bottom) {
                    barContent()
                }
        }
    }
}

// MARK: - 4. 网图单例加载器
class RemoteTailImageLoader: ObservableObject {
    static let shared = RemoteTailImageLoader()
    @Published var tailImage: UIImage? = nil
    
    private init() {
        guard let url = URL(string: "https://i.postimg.cc/k5pv6GGG/wu-biao-ti672-20260207151704.png") else { return }
        URLSession.shared.dataTask(with: url) { data, _, _ in
            if let data = data, let img = UIImage(data: data) {
                DispatchQueue.main.async {
                    self.tailImage = img
                }
            }
        }.resume()
    }
}

// MARK: - 5. 气泡背景拼接组件
struct CompositeBubbleBackground: View {
    let isFromMe: Bool
    let hasTail: Bool
    let tintColor: Color
    
    @StateObject private var loader = RemoteTailImageLoader.shared
    
    var body: some View {
        ZStack(alignment: isFromMe ? .bottomTrailing : .bottomLeading) {
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .fill(tintColor)
            
            if hasTail {
                if let uiImage = loader.tailImage {
                    Image(uiImage: uiImage)
                        .renderingMode(.template)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 21, height: 21)
                        .foregroundStyle(tintColor)
                        .scaleEffect(x: isFromMe ? 1 : -1, y: 1)
                        .offset(x: isFromMe ? -3.6 : 3.6, y: 9.6)
                }
            }
        }
        .compositingGroup()
    }
}

// MARK: - 6. 消息气泡单行视图
struct NativeMessageBubbleRow: View {
    let message: IMMessageItem
    let isPrevSameSender: Bool
    let isNextSameSender: Bool
    let isLastSentMessage: Bool
    let showTimeHeader: Bool
    let isInvisibleRevealed: Bool
    var fontSize: CGFloat = 16.5
    var isSelectionMode: Bool = false
    var isSelected: Bool = false
    var customBubbleColor: Color? = nil
    var customTextColor: Color? = nil
    var customPeerBubbleColor: Color? = nil
    var customPeerTextColor: Color? = nil
    let onRevealInvisible: () -> Void
    let onToggleSelect: () -> Void
    let onStartSelectMode: () -> Void
    let onTapback: (String?) -> Void
    let onReply: () -> Void
    let onDelete: () -> Void
    
    @Environment(\.colorScheme) private var colorScheme
    
    private let tapbackItems: [(symbol: String, label: String)] = [
        ("heart.fill", "爱心"),
        ("hand.thumbsup.fill", "赞"),
        ("hand.thumbsdown.fill", "踩"),
        ("face.smiling.inverse", "哈哈"),
        ("exclamationmark.2", "强调"),
        ("questionmark", "疑问")
    ]
    
    private var timeString: String {
        let f = DateFormatter()
        f.dateFormat = "HH:mm"
        return f.string(from: message.timestamp)
    }
    
    private var headerTimeString: String {
        let f = DateFormatter()
        if Calendar.current.isDateInToday(message.timestamp) {
            f.dateFormat = "今天 HH:mm"
        } else if Calendar.current.isDateInYesterday(message.timestamp) {
            f.dateFormat = "昨天 HH:mm"
        } else {
            f.dateFormat = "M月d日 HH:mm"
        }
        return f.string(from: message.timestamp)
    }
    
    var body: some View {
        let s = uiScale
        VStack(alignment: message.isFromMe ? .trailing : .leading, spacing: 3 * s) {
            
            if showTimeHeader {
                Text(headerTimeString)
                    .font(.system(size: 10.5 * s, weight: .medium))
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding(.top, 14 * s)
                    .padding(.bottom, 6 * s)
            }
            
            if let preview = message.replyPreview {
                Text("回复：\(preview)")
                    .font(.system(size: 10.5 * s))
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .padding(.horizontal, 20 * s)
            }
            
            HStack(alignment: .bottom, spacing: 0) {
                if isSelectionMode {
                    Button(action: onToggleSelect) {
                        Image(systemName: isSelected ? "checkmark.circle.fill" : "circle")
                            .font(.system(size: 22 * s))
                            .foregroundStyle(isSelected ? Color(hex: "#007AFF") : Color.secondary.opacity(0.45))
                            .padding(.trailing, 10 * s)
                    }
                    .buttonStyle(.plain)
                    .transition(.move(edge: .leading).combined(with: .opacity))
                }
                
                if message.isFromMe { Spacer(minLength: 80 * s) }
                
                VStack(alignment: message.isFromMe ? .trailing : .leading, spacing: 4 * s) {
                    ZStack(alignment: message.isFromMe ? .topLeading : .topTrailing) {
                        bubbleContentBody
                            .frame(maxWidth: 520 * s, alignment: message.isFromMe ? .trailing : .leading)
                            .contextMenu {
                                if !isSelectionMode {
                                    Section {
                                        ForEach(tapbackItems, id: \.symbol) { item in
                                            Button {
                                                let next = (message.tapback == item.symbol) ? nil : item.symbol
                                                onTapback(next)
                                            } label: {
                                                Label(item.label, systemImage: item.symbol)
                                            }
                                        }
                                    }
                                    Section {
                                        Button(action: onReply) {
                                            Label("回复", systemImage: "arrowshape.turn.up.left")
                                        }
                                        if !message.text.isEmpty {
                                            Button {
                                                UIPasteboard.general.string = message.text
                                            } label: {
                                                Label("拷贝", systemImage: "doc.on.doc")
                                            }
                                        }
                                        Button(action: onStartSelectMode) {
                                            Label("更多...", systemImage: "ellipsis.circle")
                                        }
                                        Button(role: .destructive, action: onDelete) {
                                            Label("删除", systemImage: "trash")
                                        }
                                    }
                                }
                            }
                        
                        if let tapSymbol = message.tapback, !isSelectionMode {
                            Image(systemName: tapSymbol)
                                .font(.system(size: 11 * s, weight: .bold))
                                .foregroundStyle(tapSymbol == "heart.fill" ? .pink : .white)
                                .frame(width: 22 * s, height: 22 * s)
                                .background(Color(hex: "#2196F3"), in: Circle())
                                .offset(x: message.isFromMe ? -8 * s : 8 * s, y: -8 * s)
                                .onTapGesture {
                                    onTapback(nil)
                                }
                        }
                    }
                    
                    if message.isFromMe && isLastSentMessage && !isSelectionMode {
                        let hasTail = !isNextSameSender
                        HStack(spacing: 4 * s) {
                            Text(timeString)
                                .font(.system(size: 9.5 * s, weight: .regular))
                            Text(message.isRead ? "已读" : "已送达")
                                .font(.system(size: 9.5 * s, weight: .bold))
                        }
                        .foregroundStyle(.secondary)
                        .padding(.trailing, hasTail ? 19 * s : 8 * s)
                    }
                }
                
                if !message.isFromMe { Spacer(minLength: 80 * s) }
            }
            .padding(.horizontal, 16 * s)
            .contentShape(Rectangle())
            .onTapGesture {
                if isSelectionMode {
                    onToggleSelect()
                }
            }
        }
        .padding(.top, isPrevSameSender ? 1.5 * s : 2 * s)
        .padding(.bottom, isNextSameSender ? 1.5 * s : 6 * s)
    }
    
    @ViewBuilder
    private var bubbleContentBody: some View {
        let s = uiScale
        let isInvisible = (message.sendEffect == "invisible") && !isInvisibleRevealed
        let hasTail = !isNextSameSender
        
        let receiveGray = colorScheme == .dark
        ? Color(UIColor.secondarySystemGroupedBackground)
        : Color(hex: "#E5E5EA")
        
        let defaultBubbleColor: Color = message.isFromMe
        ? (message.isSMS ? Color(hex: "#34C759") : Color(hex: "#007AFF"))
        : receiveGray
        
        let bubbleColor: Color = {
            if message.isFromMe {
                return customBubbleColor ?? defaultBubbleColor
            } else {
                return customPeerBubbleColor ?? receiveGray
            }
        }()
        
        let defaultTextColor: Color = message.isFromMe ? .white : .primary
        let textColor: Color = {
            if message.isFromMe {
                return customTextColor ?? defaultTextColor
            } else {
                return customPeerTextColor ?? defaultTextColor
            }
        }()
        
        VStack(alignment: .leading, spacing: 4 * s) {
            if let imgID = message.imageID,
               let data = LocalImageStore.shared.load(id: imgID),
               let uiImg = ImageBitmapCache.shared.image(from: data) {
                Image(uiImage: uiImg)
                    .resizable()
                    .scaledToFill()
                    .frame(maxWidth: 280 * s, maxHeight: 300 * s)
                    .clipShape(RoundedRectangle(cornerRadius: 20 * s, style: .continuous))
            }
            
            if !message.text.isEmpty {
                Text(message.text)
                    .font(.system(size: fontSize * s))
                    .foregroundStyle(textColor)
                    .padding(.vertical, 9 * s)
                    .padding(.horizontal, 12 * s)
                    .frame(minWidth: 48 * s)
                    .background(
                        CompositeBubbleBackground(
                            isFromMe: message.isFromMe,
                            hasTail: hasTail,
                            tintColor: bubbleColor
                        )
                    )
            }
        }
        .blur(radius: isInvisible ? 6 * s : 0)
        .onTapGesture {
            if isInvisible { onRevealInvisible() }
        }
    }
}

// MARK: - 7. 正在输入跳动气泡
struct NativeTypingIndicatorBubble: View {
    @Environment(\.colorScheme) private var colorScheme
    @State private var animate = false
    
    var body: some View {
        let s = uiScale
        let bubbleFill = colorScheme == .dark
        ? Color(UIColor.secondarySystemGroupedBackground)
        : Color(hex: "#E5E5EA")
        let dotColor = colorScheme == .dark ? Color(white: 0.65) : Color(hex: "#8E8E93")
        
        ZStack(alignment: .bottomLeading) {
            Circle()
                .fill(bubbleFill)
                .frame(width: 6 * s, height: 6 * s)
                .offset(x: -6 * s, y: 6 * s)
            
            Circle()
                .fill(bubbleFill)
                .frame(width: 12 * s, height: 12 * s)
                .offset(x: -1 * s, y: 1 * s)
            
            Capsule()
                .fill(bubbleFill)
                .frame(width: 58 * s, height: 36 * s)
            
            HStack(spacing: 4 * s) {
                ForEach(0..<3, id: \.self) { idx in
                    Circle()
                        .fill(dotColor)
                        .frame(width: 8.5 * s, height: 8.5 * s)
                        .opacity(animate ? 1.0 : 0.3)
                        .animation(
                            .easeInOut(duration: 0.55)
                            .repeatForever(autoreverses: true)
                            .delay(Double(idx) * 0.17),
                            value: animate
                        )
                }
            }
            .frame(width: 58 * s, height: 36 * s)
        }
        .padding(.leading, 4 * s)
        .padding(.bottom, 6 * s)
        .onAppear {
            animate = true
        }
    }
}

// MARK: - 8. 联系人详情 Form Sheet
@MainActor
struct NativeContactDetailSheet: View {
    let conversation: IMConversation
    @Binding var avatarPhotoItem: PhotosPickerItem?
    
    @Binding var selectedSendSoundID: Int
    @Binding var selectedReceiveSoundID: Int
    @Binding var customBubbleColorHex: String
    @Binding var customTextColorHex: String
    @Binding var customPeerBubbleColorHex: String
    @Binding var customPeerTextColorHex: String
    @Binding var customSendButtonColorHex: String
    @Binding var bgImageID: String
    @Binding var chatFontSize: Double
    let onClearAll: () -> Void
    
    @ObservedObject var viewModel = MessagesViewModel.shared
    @Environment(\.dismiss) private var dismiss
    @State private var editingName: String = ""
    @State private var bgPhotoItem: PhotosPickerItem? = nil
    
    @State private var myBubbleColor: Color = Color(hex: "#007AFF")
    @State private var myTextColor: Color = .white
    @State private var peerBubbleColor: Color = Color(hex: "#E5E5EA")
    @State private var peerTextColor: Color = .primary
    @State private var sendButtonColor: Color = Color(hex: "#007AFF")
    
    @State private var showConfirmClearInSheet: Bool = false
    
    private let bubblePresets: [(name: String, hex: String)] = [
        ("经典蓝", "#007AFF"),
        ("信息绿", "#34C759"),
        ("霓虹紫", "#AF52DE"),
        ("活力橙", "#FF9500"),
        ("曜石黑", "#1C1C1E"),
        ("樱花粉", "#FF2D55"),
        ("原生灰", "#E5E5EA")
    ]
    
    var body: some View {
        let s = uiScale
        NavigationStack {
            Form {
                Section {
                    VStack(spacing: 8 * s) {
                        PhotosPicker(selection: $avatarPhotoItem, matching: .images, photoLibrary: .shared()) {
                            NativeContactAvatarView(
                                name: conversation.name,
                                colorHex: conversation.avatarColorHex,
                                imageID: conversation.avatarImageID,
                                size: 72 * s
                            )
                        }
                        .buttonStyle(.plain)
                        Text("轻点更换头像")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity)
                    .listRowBackground(Color.clear)
                }
                
                Section("气泡文字大小调节") {
                    VStack(alignment: .leading, spacing: 8 * s) {
                        HStack {
                            Text("A").font(.system(size: 13 * s, weight: .medium))
                            Slider(value: $chatFontSize, in: 13...24, step: 0.5)
                            Text("A").font(.system(size: 22 * s, weight: .bold))
                        }
                        
                        HStack {
                            Text("当前字号: \(String(format: "%.1f", chatFontSize)) pt")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            Spacer()
                            if chatFontSize != 16.5 {
                                Button("恢复默认 (16.5 pt)") {
                                    chatFontSize = 16.5
                                }
                                .font(.caption)
                            }
                        }
                    }
                    .padding(.vertical, 4 * s)
                }
                
                Section("聊天背景壁纸") {
                    PhotosPicker(selection: $bgPhotoItem, matching: .images, photoLibrary: .shared()) {
                        HStack {
                            Label("从相册选择壁纸", systemImage: "photo.fill")
                            Spacer()
                            if !bgImageID.isEmpty,
                               let data = LocalImageStore.shared.load(id: bgImageID),
                               let uiImg = ImageBitmapCache.shared.image(from: data) {
                                Image(uiImage: uiImg)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 32 * s, height: 32 * s)
                                    .clipShape(RoundedRectangle(cornerRadius: 6 * s))
                            }
                        }
                    }
                    
                    if !bgImageID.isEmpty {
                        Button(role: .destructive) {
                            bgImageID = ""
                        } label: {
                            Label("恢复默认背景 (移除壁纸)", systemImage: "trash")
                        }
                    }
                }
                
                Section("我方气泡、文字与发送键颜色") {
                    ColorPicker("气泡颜色", selection: $myBubbleColor, supportsOpacity: false)
                        .onChange(of: myBubbleColor) { _, newColor in
                            customBubbleColorHex = newColor.toHexString()
                        }
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10 * s) {
                            ForEach(bubblePresets, id: \.hex) { preset in
                                Button {
                                    myBubbleColor = Color(hex: preset.hex)
                                    customBubbleColorHex = preset.hex
                                } label: {
                                    Circle()
                                        .fill(Color(hex: preset.hex))
                                        .frame(width: 28 * s, height: 28 * s)
                                        .overlay {
                                            if customBubbleColorHex == preset.hex {
                                                Image(systemName: "checkmark")
                                                    .font(.system(size: 12 * s, weight: .bold))
                                                    .foregroundStyle(.white)
                                            }
                                        }
                                }
                                .buttonStyle(.plain)
                            }
                        }
                        .padding(.vertical, 4 * s)
                    }
                    
                    if !customBubbleColorHex.isEmpty {
                        Button("恢复默认我方气泡颜色") {
                            customBubbleColorHex = ""
                            myBubbleColor = Color(hex: "#007AFF")
                        }
                        .font(.footnote)
                    }
                    
                    ColorPicker("文字颜色", selection: $myTextColor, supportsOpacity: false)
                        .onChange(of: myTextColor) { _, newColor in
                            customTextColorHex = newColor.toHexString()
                        }
                    
                    if !customTextColorHex.isEmpty {
                        Button("恢复默认我方文字颜色 (白色)") {
                            customTextColorHex = ""
                            myTextColor = .white
                        }
                        .font(.footnote)
                    }
                    
                    ColorPicker("发送箭头按钮颜色", selection: $sendButtonColor, supportsOpacity: false)
                        .onChange(of: sendButtonColor) { _, newColor in
                            customSendButtonColorHex = newColor.toHexString()
                        }
                    
                    if !customSendButtonColorHex.isEmpty {
                        Button("恢复默认 (跟随我方气泡)") {
                            customSendButtonColorHex = ""
                            sendButtonColor = myBubbleColor
                        }
                        .font(.footnote)
                    }
                }
                
                Section("对方气泡与文字颜色") {
                    ColorPicker("对方气泡颜色", selection: $peerBubbleColor, supportsOpacity: false)
                        .onChange(of: peerBubbleColor) { _, newColor in
                            customPeerBubbleColorHex = newColor.toHexString()
                        }
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10 * s) {
                            ForEach(bubblePresets, id: \.hex) { preset in
                                Button {
                                    peerBubbleColor = Color(hex: preset.hex)
                                    customPeerBubbleColorHex = preset.hex
                                } label: {
                                    Circle()
                                        .fill(Color(hex: preset.hex))
                                        .frame(width: 28 * s, height: 28 * s)
                                        .overlay {
                                            if customPeerBubbleColorHex == preset.hex {
                                                Image(systemName: "checkmark")
                                                    .font(.system(size: 12 * s, weight: .bold))
                                                    .foregroundStyle(preset.hex == "#E5E5EA" ? .black : .white)
                                            }
                                        }
                                }
                                .buttonStyle(.plain)
                            }
                        }
                        .padding(.vertical, 4 * s)
                    }
                    
                    if !customPeerBubbleColorHex.isEmpty {
                        Button("恢复默认对方气泡颜色 (原生灰)") {
                            customPeerBubbleColorHex = ""
                            peerBubbleColor = Color(hex: "#E5E5EA")
                        }
                        .font(.footnote)
                    }
                    
                    ColorPicker("对方文字颜色", selection: $peerTextColor, supportsOpacity: false)
                        .onChange(of: peerTextColor) { _, newColor in
                            customPeerTextColorHex = newColor.toHexString()
                        }
                    
                    if !customPeerTextColorHex.isEmpty {
                        Button("恢复默认对方文字颜色") {
                            customPeerTextColorHex = ""
                            peerTextColor = .primary
                        }
                        .font(.footnote)
                    }
                }
                
                Section("铃声音效 (轻点可试听)") {
                    Picker("我发消息时的提示音", selection: $selectedSendSoundID) {
                        ForEach(chatSendSoundOptions) { option in
                            Text(option.name).tag(option.id)
                        }
                    }
                    .onChange(of: selectedSendSoundID) { _, newSoundID in
                        if newSoundID != 0 {
                            let sound = newSoundID
                            DispatchQueue.global(qos: .userInteractive).async {
                                AudioServicesPlaySystemSound(SystemSoundID(sound))
                            }
                        }
                    }
                    
                    Picker("对方回复时的提示音", selection: $selectedReceiveSoundID) {
                        ForEach(chatReceiveSoundOptions) { option in
                            Text(option.name).tag(option.id)
                        }
                    }
                    .onChange(of: selectedReceiveSoundID) { _, newSoundID in
                        if newSoundID != 0 {
                            let sound = newSoundID
                            DispatchQueue.global(qos: .userInteractive).async {
                                AudioServicesPlaySystemSound(SystemSoundID(sound))
                            }
                        }
                    }
                }
                
                Section("联系人资料") {
                    LabeledContent("备注昵称") {
                        TextField("昵称", text: $editingName)
                            .multilineTextAlignment(.trailing)
                    }
                    LabeledContent("iMessage 号码", value: conversation.peerID)
                    Button("拷贝号码") {
                        UIPasteboard.general.string = conversation.peerID
                    }
                }
                
                Section {
                    Button(role: .destructive) {
                        showConfirmClearInSheet = true
                    } label: {
                        HStack {
                            Spacer()
                            Text("清空该对话所有聊天记录")
                            Spacer()
                        }
                    }
                }
            }
            .navigationTitle("详情")
            .navigationBarTitleDisplayMode(.inline)
            .confirmationDialog("确定要清空该会话所有聊天记录吗？此操作无法撤销。", isPresented: $showConfirmClearInSheet, titleVisibility: .visible) {
                Button("清空所有信息", role: .destructive) {
                    onClearAll()
                    dismiss()
                }
                Button("取消", role: .cancel) {}
            }
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") {
                        let trimmed = editingName.trimmingCharacters(in: .whitespacesAndNewlines)
                        guard !trimmed.isEmpty,
                              let idx = viewModel.conversations.firstIndex(where: { $0.id == conversation.id }) else {
                            dismiss()
                            return
                        }
                        viewModel.conversations[idx].name = trimmed
                        viewModel.saveConversations()
                        dismiss()
                    }
                }
            }
            .onAppear {
                editingName = conversation.name
                if !customBubbleColorHex.isEmpty {
                    myBubbleColor = Color(hex: customBubbleColorHex)
                }
                if !customTextColorHex.isEmpty {
                    myTextColor = Color(hex: customTextColorHex)
                }
                if !customPeerBubbleColorHex.isEmpty {
                    peerBubbleColor = Color(hex: customPeerBubbleColorHex)
                }
                if !customPeerTextColorHex.isEmpty {
                    peerTextColor = Color(hex: customPeerTextColorHex)
                }
                if !customSendButtonColorHex.isEmpty {
                    sendButtonColor = Color(hex: customSendButtonColorHex)
                } else if !customBubbleColorHex.isEmpty {
                    sendButtonColor = Color(hex: customBubbleColorHex)
                }
            }
            .task(id: bgPhotoItem) {
                if let item = bgPhotoItem,
                   let data = try? await item.loadTransferable(type: Data.self) {
                    if let savedID = LocalImageStore.shared.save(data: data) {
                        bgImageID = savedID
                    }
                    bgPhotoItem = nil
                }
            }
        }
    }
}
