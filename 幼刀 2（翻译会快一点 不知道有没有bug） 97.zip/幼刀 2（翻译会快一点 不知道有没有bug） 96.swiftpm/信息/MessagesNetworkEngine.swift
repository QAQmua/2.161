// 📄 文件路径：信息/MessagesNetworkEngine.swift
import SwiftUI
import Foundation

// MARK: - 跨设备实时传输数据包协议 (Codable)
public enum IMMessagePacketType: String, Codable {
    case text           // 文本/富媒体消息
    case image          // 压缩图片消息
    case tapback        // 气泡点按回应 (❤️ 👍 👎 😂 ‼️ ❓)
    case typing         // 正在输入状态同步
    case readReceipt    // 已读回执同步
}

public struct IMNetworkPacket: Codable, Identifiable {
    public var id: String               // 消息唯一 UUID
    public var packetType: IMMessagePacketType
    public var senderID: String         // 发送方本机号码 (如 "839-201")
    public var senderName: String       // 发送方昵称
    public var senderAvatarBase64: String? // 发送方头像微缩图
    public var targetID: String         // 接收方号码
    public var textContent: String?     // 文字内容
    public var imageBase64: String?     // 图片数据 Base64
    public var replyToID: String?       // 引用回复的目标消息 ID
    public var replyPreview: String?    // 引用回复的文本预览
    public var tapbackSymbol: String?   // 点按回应符号
    public var sendEffect: String?      // 发送特效 ("slam", "loud", "gentle", "invisible")
    public var isTyping: Bool?          // 是否正在输入
    public var timestamp: TimeInterval  // 发送时间戳
}

// MARK: - Apple 原生 URLSessionWebSocketTask 全球异地实时通信引擎 (MQTT over WSS)
@MainActor
public final class MessagesNetworkEngine: ObservableObject {
    public static let shared = MessagesNetworkEngine()
    
    @Published public private(set) var isConnected: Bool = false
    @Published public private(set) var connectionStatusText: String = "正在连接 iMessage 云端..."
    
    private var webSocketTask: URLSessionWebSocketTask?
    private var pingTimer: Timer?
    private var reconnectTask: Task<Void, Never>?
    private var isConnecting: Bool = false
    
    // 回调给 ViewModel 处理收到的实时数据包
    public var onReceivePacket: ((IMNetworkPacket) -> Void)?
    
    // 专属命名空间前缀，确保只接收本项目的加密信道
    private let topicPrefix = "youdao_ios27_imessage_v1/peer/"
    private var currentSubscribedID: String = ""
    
    private init() {}
    
    // MARK: - 启动并订阅本机专属号码信道
    public func connect(myDeviceID: String) {
        let cleanID = Self.normalizeID(myDeviceID)
        guard !cleanID.isEmpty else { return }
        
        if isConnected && currentSubscribedID == cleanID { return }
        currentSubscribedID = cleanID
        
        disconnect()
        isConnecting = true
        connectionStatusText = "正在连接 iMessage 云端..."
        
        // 使用全球高可用公共 MQTT over WebSocket 节点
        guard let url = URL(string: "wss://broker.emqx.io:8084/mqtt") else { return }
        var request = URLRequest(url: url)
        request.timeoutInterval = 10
        request.setValue("mqtt", forHTTPHeaderField: "Sec-WebSocket-Protocol")
        
        let session = URLSession(configuration: .default)
        let task = session.webSocketTask(with: request)
        self.webSocketTask = task
        task.resume()
        
        Task {
            do {
                // 1. 发送 MQTT CONNECT 握手包
                let clientID = "yd_im_\(cleanID)_\(Int.random(in: 1000...9999))"
                let connectData = buildMQTTConnectPacket(clientID: clientID)
                try await task.send(.data(connectData))
                
                // 2. 订阅本机专属收件箱主题
                let myTopic = topicPrefix + cleanID
                let subscribeData = buildMQTTSubscribePacket(topic: myTopic, packetID: 1)
                try await task.send(.data(subscribeData))
                
                self.isConnected = true
                self.isConnecting = false
                self.connectionStatusText = "iMessage 云端已就绪"
                
                startPingLoop()
                receiveLoop()
            } catch {
                self.isConnected = false
                self.isConnecting = false
                self.connectionStatusText = "云端重连中..."
                scheduleReconnect()
            }
        }
    }
    
    public func disconnect() {
        pingTimer?.invalidate()
        pingTimer = nil
        reconnectTask?.cancel()
        reconnectTask = nil
        webSocketTask?.cancel(with: .goingAway, reason: nil)
        webSocketTask = nil
        isConnected = false
    }
    
    // MARK: - 发送数据包给异地设备
    public func sendPacket(_ packet: IMNetworkPacket) {
        let targetClean = Self.normalizeID(packet.targetID)
        guard !targetClean.isEmpty else { return }
        
        if !isConnected {
            connect(myDeviceID: currentSubscribedID)
        }
        
        guard let jsonData = try? JSONEncoder().encode(packet) else { return }
        let targetTopic = topicPrefix + targetClean
        let publishPacket = buildMQTTPublishPacket(topic: targetTopic, payload: jsonData)
        
        webSocketTask?.send(.data(publishPacket)) { [weak self] error in
            if error != nil {
                Task { @MainActor in
                    self?.isConnected = false
                    self?.scheduleReconnect()
                }
            }
        }
    }
    
    // 标准化号码格式（去除空格与短横线，确保输入 "839-201" 和 "839201" 都能互通）
    public static func normalizeID(_ raw: String) -> String {
        return raw.trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "-", with: "")
            .replacingOccurrences(of: " ", with: "")
            .lowercased()
    }
    
    // MARK: - 持续监听下行消息
    private func receiveLoop() {
        webSocketTask?.receive { [weak self] result in
            guard let self = self else { return }
            Task { @MainActor in
                switch result {
                case .success(let message):
                    if case .data(let data) = message {
                        self.parseIncomingMQTTData(data)
                    }
                    self.receiveLoop()
                case .failure:
                    self.isConnected = false
                    self.connectionStatusText = "连接中断，正在重连..."
                    self.scheduleReconnect()
                }
            }
        }
    }
    
    private func startPingLoop() {
        pingTimer?.invalidate()
        pingTimer = Timer.scheduledTimer(withTimeInterval: 25.0, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            Task { @MainActor in
                // MQTT PINGREQ (0xC0, 0x00)
                let pingData = Data([0xC0, 0x00])
                self.webSocketTask?.send(.data(pingData)) { _ in }
            }
        }
    }
    
    private func scheduleReconnect() {
        reconnectTask?.cancel()
        reconnectTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 3_500_000_000)
            guard !Task.isCancelled else { return }
            if !self.currentSubscribedID.isEmpty {
                self.connect(myDeviceID: self.currentSubscribedID)
            }
        }
    }
    
    // MARK: - 轻量级原生 MQTT 二进制封包与解包器
    private func buildMQTTConnectPacket(clientID: String) -> Data {
        var body = Data()
        // Protocol Name "MQTT"
        body.append(contentsOf: [0x00, 0x04, 0x4D, 0x51, 0x54, 0x54])
        // Protocol Level 4 (MQTT 3.1.1)
        body.append(0x04)
        // Connect Flags: Clean Session (0x02)
        body.append(0x02)
        // Keep Alive: 60s
        body.append(contentsOf: [0x00, 0x3C])
        // Payload: Client ID
        let idBytes = Array(clientID.utf8)
        body.append(UInt8((idBytes.count >> 8) & 0xFF))
        body.append(UInt8(idBytes.count & 0xFF))
        body.append(contentsOf: idBytes)
        
        var packet = Data([0x10])
        packet.append(encodeRemainingLength(body.count))
        packet.append(body)
        return packet
    }
    
    private func buildMQTTSubscribePacket(topic: String, packetID: UInt16) -> Data {
        var body = Data()
        body.append(UInt8((packetID >> 8) & 0xFF))
        body.append(UInt8(packetID & 0xFF))
        
        let topicBytes = Array(topic.utf8)
        body.append(UInt8((topicBytes.count >> 8) & 0xFF))
        body.append(UInt8(topicBytes.count & 0xFF))
        body.append(contentsOf: topicBytes)
        body.append(0x00) // QoS 0
        
        var packet = Data([0x82])
        packet.append(encodeRemainingLength(body.count))
        packet.append(body)
        return packet
    }
    
    private func buildMQTTPublishPacket(topic: String, payload: Data) -> Data {
        var body = Data()
        let topicBytes = Array(topic.utf8)
        body.append(UInt8((topicBytes.count >> 8) & 0xFF))
        body.append(UInt8(topicBytes.count & 0xFF))
        body.append(contentsOf: topicBytes)
        body.append(payload)
        
        var packet = Data([0x30]) // Publish QoS 0
        packet.append(encodeRemainingLength(body.count))
        packet.append(body)
        return packet
    }
    
    private func encodeRemainingLength(_ length: Int) -> Data {
        var encoded = Data()
        var x = length
        repeat {
            var byte = UInt8(x % 128)
            x = x / 128
            if x > 0 { byte = byte | 128 }
            encoded.append(byte)
        } while x > 0
        return encoded
    }
    
    private func parseIncomingMQTTData(_ data: Data) {
        guard data.count >= 2 else { return }
        let bytes = [UInt8](data)
        let packetType = bytes[0] & 0xF0
        
        // 0x30 为 MQTT PUBLISH 消息帧
        if packetType == 0x30 {
            var idx = 1
            var multiplier = 1
            var remainingLength = 0
            while idx < bytes.count {
                let encodedByte = bytes[idx]
                remainingLength += Int(encodedByte & 127) * multiplier
                multiplier *= 128
                idx += 1
                if (encodedByte & 128) == 0 { break }
            }
            
            guard idx + 2 <= bytes.count else { return }
            let topicLen = (Int(bytes[idx]) << 8) | Int(bytes[idx + 1])
            idx += 2 + topicLen
            
            // QoS > 0 时跳过 2 字节 Packet ID
            let qos = (bytes[0] & 0x06) >> 1
            if qos > 0 { idx += 2 }
            
            guard idx < bytes.count else { return }
            let payloadData = Data(bytes[idx..<bytes.count])
            if let decoded = try? JSONDecoder().decode(IMNetworkPacket.self, from: payloadData) {
                self.onReceivePacket?(decoded)
            }
        }
    }
}
